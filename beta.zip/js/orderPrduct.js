setTimeout(function(){
	$("#sku-1-200003982")[0].click()
	$("#sku-2-691")[0].click()
	$("#sku-3-201336100")[0].click()
	$("#j-add-cart-btn")[0].click()

	function goToCart() {
		if($(".ui-window-bd").length>0){
			var toCartBut = $(".ui-window-bd").find(".ui-window-btn").find("a");
			toCartBut[0].click();
			stopInterval();
		}
	}

	var interval = setInterval(function(){ goToCart() }, 1000);

	function stopInterval() {
		clearInterval(interval);
	}
}, 5000);
