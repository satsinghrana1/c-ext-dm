/**
 * Dropmarket extension process workflow.
 * Developer : Sat Singh Rana
 * Date : 05-08-2019
 */
window.addEventListener("load", pageFullyLoaded, false);
function pageFullyLoaded(){
    $(function() {
        console.log( "Ready!" );
    });
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
// Get the Aliexpress CSRF token
function parse_the_csrf_token(){
	var crs =  null;				
	var e = !0,
	t = !1,
	r = void 0;
	for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) 
	{
	    var i = n.value, a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
	    
	    if (null !== a) {
	    	crs =  a[1]
	    }
	}
	return crs;	
}
   


