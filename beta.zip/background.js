
chrome.extension.onConnect.addListener(function(port) {

	console.log("Connected .....");

	port.onMessage.addListener(function(msg) {
		 
		var action = msg[0];


		var data_object = { _csrf_token_: msg[1]['_csrf_token_'],
							phoneCountry: '+1',
							contactPerson: msg[1]['first_name']+' '+msg[1]['last_name'],
							mobileNo: '0000000000',
							address: msg[1]['address1'] ,
							address2: msg[1]['address2'] ,
							zip: msg[1]['zip'] ,
							country: msg[1]['country_code'] ,
							province: msg[1]['province'] ,
							city: msg[1]['city'] ,
							features: '{"ruPassport":"taxNumber","locale":"en_US"}',
							shipcompany: 'Other',
							useLocalAddress: true
						};

		var str = [];


		for (var p in data_object)
		{
			if (data_object.hasOwnProperty(p)) {
				str.push(encodeURIComponent(p) + "=" + encodeURIComponent( data_object[p]) );
			}
		}

		var address_details = str.join("&");

		if (action == 'create-aliexpress-address') {

			var ALIEXPRESS_SHIPPING_ADDRESS_URL = 'https://ilogisticsaddress.aliexpress.com/ajaxSaveOrUpdateBuyerAddress.htm';

			var url = ALIEXPRESS_SHIPPING_ADDRESS_URL;
			var xhttp = new XMLHttpRequest();  
				xhttp.open('POST', url, false);
				xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=UTF-8');
				xhttp.onreadystatechange = function() {

					if(xhttp.readyState == 4 && xhttp.status == 200) {
						
						console.log('Address create response : ',xhttp.responseText);

						port.postMessage([{ response : xhttp.responseText }]);

					}
				}
			xhttp.send( address_details );

		}
	});
})

