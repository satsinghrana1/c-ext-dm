/**
 * Dropmarket extension process workflow.
 * Developer : Sat Singh Rana
 * Date : 05-08-2019
 */
window.addEventListener("load", pageFullyLoaded, false);   
function pageFullyLoaded(){
    $(function() {
        console.log( "Ready! Aliexpress-cart-redirect.js" );
        setTimeout(() => {
            window.location.href='https://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm';
        }, 2000);
    });
}
