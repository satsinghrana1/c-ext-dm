var domain      = "http://app.dropmarket.net/";
var dir         = "app/";
	subdomain   = 0 // change to 0 if live or directly pointed to domain
var urlPath     = domain;

if(subdomain){
	urlPath = domain+dir
}

console.log("product.js");

function getCurrentTabUrl(callback) 
{
	var queryInfo = {
		active: true,
		currentWindow: true
	};

	chrome.tabs.query(queryInfo, (tabs) => {
		var tab = tabs[0];
		var url = tab.url;
		console.assert(typeof url == 'string', 'tab.url should be a string');
		callback(url);
	});
}

function hideAll(){
	var x = document.getElementsByClassName("hidden");
	for(i = 0 ; i<x.length; i++){
		x[i].style.display = "none";
	}
}

chrome.storage.sync.get("ifOP", (order) =>{


	console.log("OP status : ->",order["ifOP"]);



	if(order["ifOP"] == 1){

		chrome.storage.sync.get("orderDetail", (prod) =>{

			//alert(prod["orderDetail"]);
			/*
				var order = {};
				order["ifOP"] = 0;
				order["first"] = 1;
				order["second"] = 0;
				order["third"] = 0;
				chrome.storage.sync.set(order);
			*/
			var json    = decodeURIComponent(prod["orderDetail"].replace(/\+/g, ' '));
			var jsonObj = JSON.parse(json);

			//alert(jsonObj.supplier)
			
			setTimeout(function(){

				if(jsonObj.skuS!="")
				{
					var skusArr = jsonObj.skuS.split(',');
					if(skusArr.length>0)
					{
						for(var cs=0;cs<skusArr.length;cs++)
						{
							if(jsonObj.supplier == 2)
							{
								$("#"+skusArr[cs])[0].click();
							}
							else if(jsonObj.supplier == 3)
							{
								$("[attrvalid="+skusArr[cs]+"]")[0].click();
							}
						}
					}
				}

				
				if(jsonObj.supplier == 2)
				{

					var order = {};
					order["ifOP"]   = 0;
					order["first"]  = 0;
					order["second"] = 1;
					order["third"]  = 0;

					chrome.storage.sync.set(order);

					var quanReq   = jsonObj.quan;
					var quanAvail = $("#j-sell-stock-num").html().replace(/\D+$/g, "");
					


					//alert( "Available Quantity = "+quanAvail);
					//alert( "Required Quantity  = "+quanReq);


					setTimeout(function(){

						if (parseInt(quanReq) <= parseInt(quanAvail)) 
						{
							for (var i = 1; i < parseInt(quanReq); i++) 
							{	
						 		$(".p-quantity-increase").click();
							}
							setTimeout(function(){
								$("#j-buy-now-btn")[0].click();
							},2000);						
							
						}
						else 
						{
							var styleStr =	"<style>.popHeader{border-bottom: 1px solid darkcyan;float: left;width: 100%;}"
												+".popUpBody{border: 1px solid black;position: fixed;top: 10px;right: 10px;width: 230px;background-color: white;height: 100px;border-radius: 3px;z-index: 9999999;align-items: center;justify-content: space-between;}"
												+".logImg{float: left;}"
												+".removePop{width:10px;float: right;}"
												+".otherPages{margin-top: 20px;width: 250px;height: 113px;}"
												+".parah{float: left;width: 100%;white-space: initial;text-align: center;font-weight: 700;line-height: 1.5;margin-top: 0;}"
												+"</style>";
								$("body").append(styleStr+"<div class='popUpBody'>"
									+"<div class='popHeader'><img class='logImg' src="+chrome.extension.getURL('assets/images/logo-full.png')+"><div class='removePop' class='cross'>x</div></div>"
									+"<div id='otherPages' class='otherPages'>"
									+"<p class='parah'>Required Quantity exceeds the available limit.</p>"
									+"</div>"
									+"</div>")

						}
					},1000);
					
					/*
						$("#j-buy-now-btn")[0].click()
						var quanAvail = $("#j-sell-stock-num").html().replace(/\D+$/g, "");
						$("#j-p-quantity-input").val(jsonObj.quan);
						var quanReq = jsonObj.quan;

						if(parseInt(quanAvail) > parseInt(quanReq)){
							//$("#j-add-cart-btn")[0].click()
							var order = {};
							order["ifOP"] = 0;
							order["first"] = 0;
							order["second"] = 1;
							order["third"] = 0;
							$("#j-buy-now-btn")[0].click()
							
							function goToCart() {
								if($(".ui-window-bd").length>0){
									var toCartBut = $(".ui-window-bd").find(".ui-window-btn").find("a");
									toCartBut[0].click();
									stopInterval();
								}
							}

							var interval = setInterval(function(){ goToCart() }, 1000);

							function stopInterval() {
								clearInterval(interval);
							}
							
						}
						else{
							var styleStr =	"<style>"
											+".popHeader{border-bottom: 1px solid darkcyan;float: left;width: 100%;}"
											+".popUpBody{border: 1px solid black;position: fixed;top: 10px;right: 10px;width: 230px;background-color: white;height: 100px;border-radius: 3px;z-index: 9999999;align-items: center;justify-content: space-between;}"
											+".logImg{float: left;}"
											+".removePop{width:10px;float: right;}"
											+".otherPages{margin-top: 20px;width: 250px;height: 113px;}"
											+".parah{float: left;width: 100%;white-space: initial;text-align: center;font-weight: 700;line-height: 1.5;margin-top: 0;}"
											+"</style>";
							$("body").append(styleStr+"<div class='popUpBody'>"
								+"<div class='popHeader'><img class='logImg' src="+chrome.extension.getURL('assets/images/logo-full.png')+"><div class='removePop' class='cross'>x</div></div>"
								+"<div id='otherPages' class='otherPages'>"
								+"<p class='parah'>Required Quantity exceeds the available limit.</p>"
								+"</div>"
								+"</div>")
						}
					*/
				}
				else if(jsonObj.supplier == 3){
					var order = {};
					order["ifOP"]   = 0;
					order["first"]  = 0;
					order["second"] = 1;
					order["third"]  = 0;
					chrome.storage.sync.set(order);

					$("#quantity").val(jsonObj.quan);
					//$("#addToCart")[0].click()
					$("#buyItNow")[0].click()
					/*
						function goToCart() {
							if($("#continueShopping").length>0){
								var toCartBut = $(".ttsubmit").find(".n-yellow-button").find("a");
								toCartBut[0].click();
								stopInterval();
							}
						}

						var interval = setInterval(function(){ goToCart() }, 1000);

						function stopInterval() {
							clearInterval(interval);
						}
					*/
				}
			},3000);
		});
	}
});