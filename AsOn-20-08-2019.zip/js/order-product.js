/**
 * Dropmarket extension process workflow.
 * Developer : Sat Singh Rana
 * Date : 05-08-2019
 */
window.addEventListener("load", pageFullyLoaded, false);   
function pageFullyLoaded(){
    $(function() {
        console.log( "Ready! order-product.js" );
        
        chrome.storage.sync.get(null, function(params) {

            console.log(params.order_process_flow);
            if(params.order_process_flow=='order_btn_clicked'){
                var order_cookie_data = readCookie('dm_order_details');
                var json    = decodeURIComponent(order_cookie_data.replace(/\+/g, ' '));
			    var jsonObj = JSON.parse(json);
                
                console.log(jsonObj);

                chrome.storage.sync.set({'order_data': jsonObj});
                chrome.storage.sync.set({'order_process_flow': 'order_data_set'});

                window.location.href=jsonObj.url;

            }
            
        });
       
    });
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}