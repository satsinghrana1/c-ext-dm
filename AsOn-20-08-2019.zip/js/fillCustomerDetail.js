/*
var order = {};
order["ifOP"] = 0;
order["first"] = 0;
order["second"] = 1;
order["third"] = 0;
chrome.storage.sync.set(order);
*/


window.addEventListener("load", pageFullyLoaded, false);

var CUSTOMER_DATA = null;


// CHECK IF THE DIV WITH THE FOLLOWING CLASS EXIST.

function check_for_the_view_of_the_order_page(){

	var v1 = '.process-min .ui-step.ui-step-normal';

	var v2 = '.shipping-info';
	var order_view = null;	
	if ($(v1).length > 0) {
		order_view = 'v1';		
	}	
	if ($(v2).length > 0) {
		order_view = 'v2';		
	}
	return order_view;	
}





// COUNT ALIEXPRESS ADDRESSES.

function count_aliexpress_address(shipping_address_ali){
	
	if (shipping_address_ali.length > 9) {
		
		delete_an_aliexpress_address(shipping_address_ali);
		
	} else {
		
		create_new_aliexpress_address(CUSTOMER_DATA);
		
	}	
}

// CREATE NEW ADDRESS ON ALIEXPRESS

function create_new_aliexpress_address(CUSTOMER_DATA_OBJECT){
	
	var ALIEXPRESS_SHIPPING_ADDRESS_URL = 'https://ilogisticsaddress.aliexpress.com/ajaxSaveOrUpdateBuyerAddress.htm';
	
	
	// console.log($.ajaxSettings)
	// delete $.ajaxSettings.accepts;
	console.log($.ajaxSettings)
		 	// return
	
	
	$.ajax({ 
	     url : ALIEXPRESS_SHIPPING_ADDRESS_URL,
		 method : 'POST',
		 data : CUSTOMER_DATA_OBJECT,
		 beforeSend: function(xhr){
		 	
		 
		 	
		 },
		 success : function(res){

		 	
		 	setCookie('dm_address_fill_status','DONE')
		 	// window.location.reload();

		 	
		 },
		 error : function(a,b){
		 	console.log(a)
		 	console.log(b)
		 }
	});
}

// GET THE CSRF TOKEN FROM THE PAGE.
 
function parse_the_csrf_token(){
	var crs =  null;				
	var e = !0,
	t = !1,
	r = void 0;

	for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) 
	{
	    var i = n.value, a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
	    
	    if (null !== a) {
	    	crs =  a[1]
	    }
	}
	
	return crs;	
}

// DELETE AN ADDRESS FROM ALIEXPRESS.

function delete_an_aliexpress_address(shipping_address_ali){
	
	addressID = shipping_address_ali[0]['shippingMethodId'];
	
	var crs = parse_the_csrf_token();
	
    var deleteAddress = 'https://ilogisticsaddress.aliexpress.com/ajaxDeleteLogisticsAddress.htm?addressId='+addressID+'&_csrf_token_='+crs;
    
    $.ajax({
    		url : deleteAddress,
    		method : 'GET',
    		beforeSend: function(xhr){
			 	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			 	xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
			 },
    		success : function(res){					                    			
    			window.location.reload();
    		},
    		error : function(e,r){
    			console.log(e)					                    				
    			console.log(r)					                    				
    		}
    });
}

// GET REQUIRED DATA

function get_required_data(){
	var e = !0, t = !1, r = void 0;
	var orderdItemId = null;
	var skuAttr = null;
	var umidToken = null;
	var productId = null;
	
    for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
    	
    	if (n.value.innerText.indexOf('"skuAttr":') != -1) {
    		
    		var data  = n.value.innerText.match(/skuAttr":(.*),/);
    		var data2 = n.value.innerText.match(/umidToken":(.*),/);
    		var data3 = n.value.innerText.match(/shippingCompany":(.*),/);   		
    		var data4 = n.value.innerText.match(/productId":(.*),/);   		
    		
    		skuAttr = data[1];
    		umidToken = data2[1];
    		shippingCompany = data3[1];    		
    		productId = data4[1];    		
    		
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = $.trim(skuAttr);
    		
    		umidToken = umidToken.replace('"','');
    		umidToken = umidToken.replace('"','');
    		umidToken = $.trim(umidToken);
    		
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = $.trim(shippingCompany);
    		
    		productId = productId.replace('"','');
    		productId = productId.replace('"','');
    		productId = $.trim(productId);
    	}
    }
    return {skuAttr : skuAttr, umidToken : umidToken, shippingCompany : shippingCompany, productId : productId};
}


// IS ALIEXPRESS ADDRESS IS FULL

function is_aliexpress_address_full(CUSTOMER_DATA){
	
	var url = "https://shoppingcart.aliexpress.com/api/1.0/orders.htm";
	
	var required_data = get_required_data();  
    
    $.ajax({
    	url : url,
    	method : 'POST',
    	data : {
    		itemIds: '',
			objectId: required_data['productId'],
			aeOrderFrom: 'main_detail',
			shippingCompany: required_data['shippingCompany'],
			promiseId: '',
			itemCondition: '',
			skuAttr: required_data['skuAttr'],
			quantity: '1',
			pageQuantity: '',
			selectedAddressId: '',
			changeAddress: '',
			provinceCode: '',
			cityCode: '',
			splitOrder: '',
			splitOrderIds: '',
			splitOrderNum: '',
			splitOrderShopCartIds: '',
			umidToken: required_data['umidToken'],
			ua: '',
    	},
    	beforeSend: function(xhr){
    		console.log('xhr',xhr)
		 	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		 	xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
		 	
		 	return
		},			                    	
    	success : function(res){
    		
    		if (null != res.shipping.availableShippingMethods) {
    			
    			count_aliexpress_address( res.shipping.availableShippingMethods );
    			
    		} else {
    			
    			create_new_aliexpress_address(CUSTOMER_DATA);	
    			
    		}			
    	},
    	error : function(e,r){
    		console.log(e)
    		console.log(r)
    	}
    });		
	
}


// CREATE A COOKIE

function setCookie(name, value) {
   var date = new Date();
   date.setTime(date.getTime()+(7*1000));
   var expires = "; expires="+date.toGMTString();

   document.cookie = name+"="+value+expires+"; path=/";
}

// GET THE COOKIE
function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}




















function pageFullyLoaded(){
	
	chrome.storage.sync.get("second", (order) =>{


		if(order["second"] == 1) {

			var order = {};
			console.log("fillCustomerDetails.js");
			
			
			chrome.storage.sync.get("orderDetail", (prod) => {
			
				var json 	= decodeURIComponent(prod["orderDetail"].replace(/\+/g, ' '));
				var jsonObj = JSON.parse(json);

				console.log("order json ->",jsonObj);

				
			
				setTimeout(function(){

					console.log('check the spplier now.')					
			
					if (jsonObj.supplier == 2) {

						console.log('supplier is Aliexpress.');
						
						
						console.log("Page loaded!"); 	

						// CHECK FOR THE PAGE VIEW...
						
						var view = check_for_the_view_of_the_order_page();
						
						if (view == 'v2') {	
							
							//ORDER PAGE VIEW 2	// GET THE CSRF TOKEN
								
								
							if (getCookie('dm_address_fill_status')) {
								
								console.log( getCookie('dm_address_fill_status') );
								
								return;
							}
							
							
							
							var crs =  parse_the_csrf_token();
								
							CUSTOMER_DATA =	{   contactPerson: jsonObj.contactPerson,
											    mobileNo: jsonObj.phone_number,
												phoneCountry: jsonObj.country_code,
												country: jsonObj.country,
												province: jsonObj.province,
												city: jsonObj.city,
												address: jsonObj.address1,
												address2: jsonObj.address2,
												zip: jsonObj.zip,
												isDefault: true,
												features: {"locale":"en_US"},
												_csrf_token_: crs,
											};
								
							is_aliexpress_address_full(CUSTOMER_DATA);
							
							 
						} 
							
							
						if (view == 'v1') {
							
							console.log('supplier is Aliexpress.');


							if($(".sa-address-row").length!=0) {

								document.getElementsByClassName('sa-order-add-a-new-address')[0].click();


								$("input[name=contactPerson]").val(jsonObj.contactPerson);								

								var country = document.getElementsByName("country")[0];								
									country.value = jsonObj.country;						
								
								var event   = new Event('change');
									
								country.dispatchEvent(event);										
								
								$("input[name=address]").val(jsonObj.address1);									
								$("input[name=city]").val(jsonObj.city);									
								$("input[name=zip]").val(jsonObj.zip);

								$("input[name=phoneCountry]").val(jsonObj.country_code);
								$("input[name=mobileNo]").val(jsonObj.phone_number);
								
								setTimeout(function(){

									$("input[name=province]").val(jsonObj.province);
									$("input[name=province]").next().val(jsonObj.province);

									order["ifOP"] 	= 0;
									order["first"] 	= 0;
									order["second"] = 0;
									order["third"] 	= 1;

									chrome.storage.sync.set(order);


									document.getElementsByClassName('sa-confirm')[0].click();

								},1000);

							}else {

								$("input[name=contactPerson]").val(jsonObj.contactPerson);								

								var country = document.getElementsByName("country")[0];								
									country.value = jsonObj.country;
								
								var event   = new Event('change');
									
									country.dispatchEvent(event);										
									
									$("input[name=address]").val(jsonObj.address1);									
									$("input[name=city]").val(jsonObj.city);									
									$("input[name=zip]").val(jsonObj.zip);
									// $("input[name=mobileNo]").val('9876543210');

									$("input[name=phoneCountry]").val(jsonObj.country_code);
									$("input[name=mobileNo]").val(jsonObj.phone_number);

									order["ifOP"] 	= 0;
									order["first"] 	= 0;
									order["second"] = 0;
									order["third"] 	= 1;

									chrome.storage.sync.set(order);
									
									setTimeout(function(){

										$("input[name=province]").val(jsonObj.province);
										$("input[name=province]").next().val(jsonObj.province);
										
										document.getElementsByClassName('sa-confirm')[0].click();

									},1000);
														
							}	
						}
						

					}

					if (jsonObj.supplier == 3) {

						console.log('supplier is Dhgate.')

						console.log($('.j-add-address').length)
					
						if($('.j-add-address').length>0){

							document.getElementsByClassName("j-address-edit")[0].click();
							$("input[name=contactname]").val(jsonObj.firstName)				
							$("input[name=lastname]").val(jsonObj.lastName)						

							var selections = document.querySelector('.j-country-select');
								selections.value = jsonObj.country;
							
							var evt = document.createEvent("HTMLEvents");
							
							evt.initEvent("change", true, true);
							
							selections.dispatchEvent(evt);
							
							$("input[name=address1]").val(jsonObj.address1)
							
							
							$("#city").val(jsonObj.city)

							$(".j-address-dialog").find("#_statevalue1").val(jsonObj.province);

							console.log("jsonObj.province = ",jsonObj.province)

							$("#postalcode").val(jsonObj.zip);

							$(".j-address-dialog").find("#areacode").val(jsonObj.country_code);						
							$(".j-address-dialog").find("#phonenumber").val(jsonObj.phone_number);

							

							setTimeout(function(){

								$(".j-save-address").trigger('click');

							},1000)
						

							$(".j-addremark").val(jsonObj.note);


							if($(".form-msg-warning:visible").length == 0){
								
								setTimeout(function(){
									$(".j-nextpage")[0].click();
								},2000);
							}						
							else{

								var styleStr =	"<style>"
											+".popHeader{border-bottom: 1px solid darkcyan;float: left;width: 100%;}"
											+".popUpBody{border: 1px solid black;position: fixed;top: 10px;right: 10px;width: 230px;background-color: white;height: 100px;border-radius: 3px;z-index: 9999999;align-items: center;justify-content: space-between;}"
											+".logImg{float: left;}"
											+".removePop{width:10px;float: right;}"
											+".otherPages{margin-top: 20px;width: 250px;height: 113px;}"
											+".parah{float: left;width: 100%;white-space: initial;text-align: center;font-weight: 700;line-height: 1.5;margin-top: 0;}"
											+"</style>";
								$("body").append(styleStr+"<div class='popUpBody'>"
									+"<div class='popHeader'><img class='logImg' src="+chrome.extension.getURL('assets/images/logo-full.png')+"><div class='removePop' class='cross'>x</div></div>"
									+"<div id='otherPages' class='otherPages'>"
									+"<p class='parah'>Please fill out the pending details.</p>"
									+"</div>"
									+"</div>")
							}

						}
						else{

							$("input[name=contactname]").val(jsonObj.firstName)
							
							$("input[name=lastname]").val(jsonObj.lastName)

							// $("#lastname").val(jsonObj.lastName)

							var selections = document.querySelector('.j-country-select');
								selections.value = jsonObj.country;
							
							var evt = document.createEvent("HTMLEvents");
							
							evt.initEvent("change", true, true);
							
							selections.dispatchEvent(evt);
							
							$("input[name=address1]").val(jsonObj.address1)
							
							
							$("#city").val(jsonObj.city);
							$("#_statevalue1").val(jsonObj.province);
							$("#postalcode").val(jsonObj.zip);
							
							

							$(".j-address-dialog").find("#areacode").val(jsonObj.country_code);						
							$(".j-address-dialog").find("#phonenumber").val(jsonObj.phone_number);

							

							// $(".j-addressform-save").trigger('click');
							



							$(".j-addremark").val(jsonObj.note);

							if($(".form-msg-warning:visible").length == 0){
								
								setTimeout(function(){
									$(".j-nextpage")[0].click();
								},2000);
							}						
							else{

								var styleStr =	"<style>"
											+".popHeader{border-bottom: 1px solid darkcyan;float: left;width: 100%;}"
											+".popUpBody{border: 1px solid black;position: fixed;top: 10px;right: 10px;width: 230px;background-color: white;height: 100px;border-radius: 3px;z-index: 9999999;align-items: center;justify-content: space-between;}"
											+".logImg{float: left;}"
											+".removePop{width:10px;float: right;}"
											+".otherPages{margin-top: 20px;width: 250px;height: 113px;}"
											+".parah{float: left;width: 100%;white-space: initial;text-align: center;font-weight: 700;line-height: 1.5;margin-top: 0;}"
											+"</style>";
								$("body").append(styleStr+"<div class='popUpBody'>"
									+"<div class='popHeader'><img class='logImg' src="+chrome.extension.getURL('assets/images/logo-full.png')+"><div class='removePop' class='cross'>x</div></div>"
									+"<div id='otherPages' class='otherPages'>"
									+"<p class='parah'>Please fill out the pending details.</p>"
									+"</div>"
									+"</div>")
							}

						}
					}

				},1000);


			});
		}else{

			console.log("here in third")
			chrome.storage.sync.get("orderDetail", (prod) => {

				var json 	= decodeURIComponent(prod["orderDetail"].replace(/\+/g, ' '));
				var jsonObj = JSON.parse(json);
				
				setTimeout(function(){

					$(".p-message").find("textarea").val(jsonObj.note);

				},1000);

			});

		}
	});

}
















