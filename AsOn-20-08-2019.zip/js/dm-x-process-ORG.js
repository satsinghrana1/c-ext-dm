//order process file.
window.addEventListener("load", pageFullyLoaded, false);   
function pageFullyLoaded(){
    $(function() {
        console.log( "Dm extension runs." );

        /*---------------------------------*/        
        /*---------------------------------*/
        // change_process_state('state_for');
        current_process_state();
        // return;
        // On order btn click.
        // Re-populate the process state Object.
        $('.orderBtn').click(function(ev) {

             var link  = $(this).attr("href");
                { dm_order_button_click,
                dm_on_product_page,
                dm_on_cart_page,
                dm_check_cart_count,
                dm_delete_cart_items,
                dm_add_to_cart,
                dm_go_to_order_confirm_page,
                dm_get_address_count,
                dm_delete_address,
                dm_create_address,
                dm_fill_order_note,
                dm_remove_order_cookie_remove_process_state}


            if($.cookie("dm_order_process") == undefined){
                console.log('Set the order cookie for 1 minute.');
                ev.preventDefault();
                                
                var date = new Date();
                    date.setTime(date.getTime() + (60 * 2000));
                    $.cookie('dm_order_process', 1, { expires: date });

                    setTimeout(function(){
                        var id = $.now();
                        var tempA = "<a id='"+id+"' href='"+link+"' target='_blank'></a>";
                            $('body').append(tempA);

                            setTimeout(function(){
                                $("#"+id)[0].click();                               
                                $("#"+id).remove();
                            },500);
                    },300);

            } else {
                console.log('Please wait an order is already in progress!');
            }

        
            /*
                chrome.storage.sync.set({dm_order_process: null});   

                var dm_order_process = {
                    'dm_order_btn_clk'  : 1,
                    'dm_order_cookie'   : 0,
                    'dm_empty_cart'     : 0,
                    'dm_add_to_cart'    : 0,
                    'dm_empty_address'  : 0,
                    'dm_create_address' : 0,
                    'dm_fill_o_note'    : 0,
                    'dm_process_done'   : 0,
                };
                // initiate_process_state
                chrome.storage.sync.set({dm_order_process: dm_order_process});   
            */

        });



        
        /*---------------------------------*/
        /*---------------------------------*/
        
        if ($('#dm-order-product-page').length==1) {
            $('body').html('Read the cookie and set to local storage.');
            
            var order_cookie_data = readCookie('dm_order_details');
            var json              = decodeURIComponent(order_cookie_data.replace(/\+/g, ' '));
			var jsonObj           = JSON.parse(json);
                
            console.log(jsonObj);

            chrome.storage.sync.set({'order_data': null});
            chrome.storage.sync.set({'order_data': jsonObj});

            var dm_order_process = {
                'dm_order_btn_clk'  : 0,
                'dm_order_cookie'   : 1,
                'dm_empty_cart'     : 0,
                'dm_add_to_cart'    : 0,
                'dm_empty_address'  : 0,
                'dm_create_address' : 0,
                'dm_fill_o_note'    : 0,
                'dm_process_done'   : 0,
            };
            
            chrome.storage.sync.set({dm_order_process: dm_order_process});
            
            // Go to vendor site
            setTimeout(() => {
                window.location.href = jsonObj.url;
            }, 2000);
            
        }
        
        /*---------------------------------*/
        /*---------------------------------*/
        
        if($('.product-main-wrap').length==1) {

            chrome.storage.sync.get(['dm_order_process'], function(result) {
                console.log(result['dm_order_process']['dm_order_cookie']);
                // if order cookie set go to Cart page
                if (result['dm_order_process']['dm_order_cookie']) {
                    var dm_order_process = {
                        'dm_order_btn_clk'  : 0,
                        'dm_order_cookie'   : 0,
                        'dm_empty_cart'     : 1,
                        'dm_add_to_cart'    : 0,
                        'dm_empty_address'  : 0,
                        'dm_create_address' : 0,
                        'dm_fill_o_note'    : 0,
                        'dm_process_done'   : 0,
                    };
                    
                    chrome.storage.sync.set({dm_order_process: dm_order_process});

                    // go to cart page
                    setTimeout(() => {
                        
                        window.location.href = 'https://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm';
                    }, 2000);

                    
                }
            });


        }

        /*---------------------------------*/
        /*---------------------------------*/
        
        if (window.location.href.indexOf('shoppingcart') > -1) {
            // on cart page check if extension process is running


            chrome.storage.sync.get(['dm_order_process'], function(result) {
                console.log(result);

                if (result['dm_order_process']['dm_empty_cart'] == 1) {

                    // check for cart items Count.
                    
                    $.ajax({
                        url : 'https://shoppingcart.aliexpress.com/api/1.0/cart.do',
                        method :'GET',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('content-encoding' , 'gzip');
                            xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                        },
                        success: function(res){
        
                            var p_quantity = res.captain.quantity;
                            
                            if (p_quantity > 0) {
                                // cart is not empty
                                console.log('cart is not empty');

                                var item_ids   = [];

                                $.each(res.stores, function(indexStore,dataStore){
                                    $.each(dataStore.storeList, function(indexstoreList,datastoreList){
                                        $.each(datastoreList.products, function(indexdatastoreListproducts,datastoreListproducts){
                                            item_ids.push(datastoreListproducts.itemId);									
                                        });
                                    });
                                });

                                // empty the cart
                                console.log('items to be deleted :', item_ids);

                                /*-------------------------------------*/
                                /*-------------------------------------*/

                                var token      = parse_the_csrf_token();			
                                var items_data = [];
                                
                                $.each(item_ids, function(i,d){
                                    items_data.push({itemId : d, quantity:0});
                                });
                            
                                var prm = '{"updates":'+JSON.stringify(items_data)+',"action":"DELETE_ITEMS","selected":"","_csrf_token_":"'+token+'"}';
                                var url = "https://shoppingcart.aliexpress.com/api/1.0/cart.do";
                                var xhttp = new XMLHttpRequest();  
                                    xhttp.open('POST', url, true);
                                    
                                    xhttp.setRequestHeader('Content-type', 'application/json');
                                    xhttp.onreadystatechange = function() {
                                        if(xhttp.readyState == 4 && xhttp.status == 200) {
                                            console.log('Post request response : ',xhttp.responseText);

                                            var dm_order_process = {
                                                'dm_order_btn_clk'  : 0,
                                                'dm_order_cookie'   : 0,
                                                'dm_empty_cart'     : 0,
                                                'dm_add_to_cart'    : 1,
                                                'dm_empty_address'  : 0,
                                                'dm_create_address' : 0,
                                                'dm_fill_o_note'    : 0,
                                                'dm_process_done'   : 0,
                                            };
                                            
                                            chrome.storage.sync.set({dm_order_process: dm_order_process});

                                            window.location.reload();
                                        }
                                    }
                                    xhttp.send(prm);

                                    
                                
                                /*-------------------------------------*/
                                /*-------------------------------------*/

                            }else{
                                // cart is empty add to cart the items
                                console.log('cart is empty');
                                console.log('Add to cart');


                                var atc_url = 'https://shoppingcart.aliexpress.com/addToShopcart4Js.htm?productId=32858482533&quantity=1&country=IN&company=CAINIAO_STANDARD&promiseId=&cartfrom=main_detail&skuAttr=14%3A193%23BLACK%3B200000124%3A3434&skuId=65407548612&_csrf_token_=17yj472ga1chz&callback=__jp12';
                                
                                
                                $.ajax({
                                    url : atc_url ,
                                    method :'GET',
                                    beforeSend: function(xhr) {
                                        xhr.setRequestHeader('content-encoding' , 'gzip');
                                        xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                                    },
                                    success: function(res){                            
                                        console.log('Added to cart reload after 2 sec.');

                                        var dm_order_process = {
                                        'dm_order_btn_clk'  : 0,
                                        'dm_order_cookie'   : 0,
                                        'dm_empty_cart'     : 0,
                                        'dm_add_to_cart'    : 0,
                                        'dm_empty_address'  : 0,
                                        'dm_go_to_shipping' : 1,
                                        'dm_create_address' : 0,
                                        'dm_fill_o_note'    : 0,
                                        'dm_process_done'   : 0,
                                    };
                                    chrome.storage.sync.set({dm_order_process: dm_order_process});   
                                        window.location.reload();      
                                    },
                                    error : function(err,e){
                                        alert('Error: While adding to cart.');
                                    }
                                });
                                    
                            }
                                
        
        
                        },
                        error : function(err,e){
                            alert('Error: While checking cart items.');
                        }
                    });
                    



                } else if(result['dm_order_process']['dm_add_to_cart'] == 1) {
                    // add product to cart
                    console.log('add product to cart.');

                    var atc_url = 'https://shoppingcart.aliexpress.com/addToShopcart4Js.htm?productId=32858482533&quantity=1&country=IN&company=CAINIAO_STANDARD&promiseId=&cartfrom=main_detail&skuAttr=14%3A193%23BLACK%3B200000124%3A3434&skuId=65407548612&_csrf_token_=17yj472ga1chz&callback=__jp12';
                                                    
                    $.ajax({
                        url : atc_url ,
                        method :'GET',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('content-encoding' , 'gzip');
                            xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                        },
                        success: function(res){                            
                            console.log('Added to cart reload after 2 sec.');

                            var dm_order_process = {
                            'dm_order_btn_clk'  : 0,
                            'dm_order_cookie'   : 0,
                            'dm_empty_cart'     : 0,
                            'dm_add_to_cart'    : 0,
                            'dm_empty_address'  : 0,
                            'dm_create_address' : 0,
                            'dm_go_to_shipping' : 1,
                            'dm_fill_o_note'    : 0,
                            'dm_process_done'   : 0,
                        };
                        
                        chrome.storage.sync.set({dm_order_process: dm_order_process});
                            
                        window.location.href = 'https://shoppingcart.aliexpress.com/order/confirm_order.htm?objectId=32800898453&from=aliexpress&countryCode=IN&shippingCompany=Other&provinceCode=&cityCode=&promiseId=&aeOrderFrom=main_detail&skuAttr=200000369%3A1394%3B200000783%3A29%23White+Silver+6mm&skuId=67059622038&skucustomAttr=&quantity=1';
                            

                        },
                        error : function(err,e){
                            alert('Error: While adding to cart.');
                        }
                    });
                    
                } else if(result['dm_order_process']['dm_create_address'] == 1) {
                    // create the new customer address on aliexpress
                    console.log('Create address');

                    var dm_order_process = {
                        'dm_order_btn_clk'  : 0,
                        'dm_order_cookie'   : 0,
                        'dm_empty_cart'     : 0,
                        'dm_add_to_cart'    : 0,
                        'dm_empty_address'  : 0,
                        'dm_create_address' : 0,
                        'dm_go_to_shipping' : 0,
                        'dm_fill_o_note'    : 1,
                        'dm_process_done'   : 0,
                    };
                    
                    chrome.storage.sync.set({dm_order_process: dm_order_process});

                    // Go to shipping page

                    // window.location.href = 'https://shoppingcart.aliexpress.com/order/confirm_order.htm?objectId=32800898453&from=aliexpress&countryCode=IN&shippingCompany=Other&provinceCode=&cityCode=&promiseId=&aeOrderFrom=main_detail&skuAttr=200000369%3A1394%3B200000783%3A29%23White+Silver+6mm&skuId=67059622038&skucustomAttr=&quantity=1';

                    var url           = "https://shoppingcart.aliexpress.com/api/1.0/orders.htm";
                    var required_data = get_required_data();
                    
                
                    $.ajax({
                        url : url,
                        method : 'POST',
                        data : {
                            itemIds: '',
                            objectId: required_data['productId'],
                            aeOrderFrom: 'main_detail',
                            shippingCompany: required_data['shippingCompany'],
                            promiseId: '',
                            itemCondition: '',
                            skuAttr: required_data['skuAttr'],
                            quantity: '1',
                            pageQuantity: '',
                            selectedAddressId: '',
                            changeAddress: '',
                            provinceCode: '',
                            cityCode: '',
                            splitOrder: '',
                            splitOrderIds: '',
                            splitOrderNum: '',
                            splitOrderShopCartIds: '',
                            umidToken: required_data['umidToken'],
                            ua: '',
                        },
                        beforeSend: function(xhr){
                            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                            xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
                        },			                    	
                        success : function(res){
        
                            if (null != res.shipping.availableShippingMethods) {

                                console.log('Total address are : '+ res.shipping.availableShippingMethods.length);


                                $.each(res.shipping.availableShippingMethods, function(a,b) {
                                    // delete address from aliexpress
                                    delete_an_aliexpress_address(b.shippingMethodId);                                   
                                });



                                create_new_aliexpress_address(null);
                                setTimeout(() => {
                                    
                                    // window.location.reload();

                                }, 2000);


                                
                            }else{
                                console.log('No shipping address.');
                                // create new shipping address
                                create_new_aliexpress_address(null);


                            }
                        },
                        error : function(e,r){
                            console.log(e)
                            console.log(r)
                        }
                    });
                    


                } else if(result['dm_order_process']['dm_go_to_shipping'] == 1) {

                    var dm_order_process = {
                        'dm_order_btn_clk'  : 0,
                        'dm_order_cookie'   : 0,
                        'dm_empty_cart'     : 0,
                        'dm_add_to_cart'    : 0,
                        'dm_empty_address'  : 0,
                        'dm_go_to_shipping' : 0,
                        'dm_create_address' : 1,
                        'dm_fill_o_note'    : 0,
                        'dm_process_done'   : 0,
                    };
                    
                    chrome.storage.sync.set({dm_order_process: dm_order_process});

                    // var availableProductShopcartIds = $('.product-field.product-select input').attr('ae_object_value');
                    
                    window.location.href = 'https://shoppingcart.aliexpress.com/order/confirm_order.htm?objectId=32800898453&from=aliexpress&countryCode=IN&shippingCompany=Other&provinceCode=&cityCode=&promiseId=&aeOrderFrom=main_detail&skuAttr=200000369%3A1394%3B200000783%3A29%23White+Silver+6mm&skuId=67059622038&skucustomAttr=&quantity=1';


                }
            });
     
        }

        /*---------------------------------*/
        /*---------------------------------*/


    });
}



/**------------------------------------ */
// Required functions
/**------------------------------------ */

function change_process_state(state_for) {
    // chrome.storage.sync.get(['dm_order_process'], function(result) {
    chrome.storage.sync.get(null, function(result) {
        console.log(result.dm_order_process);
    });    
}
function current_process_state() {
    // chrome.storage.sync.get(['dm_order_process'], function(result) {
    chrome.storage.sync.get(null, function(result) {
        console.log(result);
        if(result['dm_order_process']==undefined){

            console.log('No order process found!');

        }else{
            console.log('Order process exist.');

            $.each(result['dm_order_process'], function(key,value) {
                if (value==1) {
                    console.log('Process state is : '+key);
                }
            });        
        }
    });    
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function parse_the_csrf_token() {
	var crs =  null;				
	var e = !0,
	t = !1,
	r = void 0;
	for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) 
	{
	    var i = n.value, a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
	    
	    if (null !== a) {
	    	crs =  a[1]
	    }
	}
	return crs;	
}
function parse_the_availableProductShopcartIds() {

    for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
        var i = n.value;
        console.log(i.innerText)
        a = i.innerText.match(/availableProductShopcartIds":\s"([\d,]+)",/);
        if (null !== a) return a[1]
    }
}
function get_required_data() {

	var skuAttr = null;
	var umidToken = null;
	var productId = null;
	
    for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
    	
    	if (n.value.innerText.indexOf('"skuAttr":') != -1) {
    		
    		var data  = n.value.innerText.match(/skuAttr":(.*),/);
    		var data2 = n.value.innerText.match(/umidToken":(.*),/);
    		var data3 = n.value.innerText.match(/shippingCompany":(.*),/);   		
    		var data4 = n.value.innerText.match(/productId":(.*),/);   		
    		
    		skuAttr         = data[1];
    		umidToken       = data2[1];
    		shippingCompany = data3[1];    		
    		productId       = data4[1];    		
    		
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = $.trim(skuAttr);
    		
    		umidToken = umidToken.replace('"','');
    		umidToken = umidToken.replace('"','');
    		umidToken = $.trim(umidToken);
    		
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = $.trim(shippingCompany);
    		
    		productId = productId.replace('"','');
    		productId = productId.replace('"','');
    		productId = $.trim(productId);
    	}
    }
    return {skuAttr : skuAttr, umidToken : umidToken, shippingCompany : shippingCompany, productId : productId};
}
function get_address_list() {
	
    var url = "https://shoppingcart.aliexpress.com/api/1.0/orders.htm";

    var required_data = get_required_data();     
    
    $.ajax({
    	url : url,
    	method : 'POST',
    	data : {
    		itemIds: '',
			objectId: required_data['productId'],
			aeOrderFrom: 'main_detail',
			shippingCompany: required_data['shippingCompany'],
			promiseId: '',
			itemCondition: '',
			skuAttr: required_data['skuAttr'],
			quantity: '1',
			pageQuantity: '',
			selectedAddressId: '',
			changeAddress: '',
			provinceCode: '',
			cityCode: '',
			splitOrder: '',
			splitOrderIds: '',
			splitOrderNum: '',
			splitOrderShopCartIds: '',
			umidToken: required_data['umidToken'],
    	},
    	beforeSend: function(xhr){
		 	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		 	xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
		},			                    	
    	success : function(res){
            console.log(res);   		
    		// if (null != res.shipping.availableShippingMethods) {
    		// 	count_aliexpress_address( res.shipping.availableShippingMethods );
    		// } else {
    		// 	create_new_aliexpress_address(CUSTOMER_DATA);	
    		// }			
    	},
    	error : function(e,r){
    		console.log(e)
    		console.log(r)
    	}
    });		
	
}
function delete_an_aliexpress_address(address_id) {
	
	var crs = parse_the_csrf_token();
	
    var deleteAddress = 'https://ilogisticsaddress.aliexpress.com/ajaxDeleteLogisticsAddress.htm?addressId='+address_id+'&_csrf_token_='+crs;

    $.ajax({
    		url : deleteAddress,
    		method : 'GET',
    		beforeSend: function(xhr){
			 	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			 	xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
			 },
    		success : function(res){					                    			
    			console.log('Address deleted.');
    		},
    		error : function(e,r){
    			console.log(e)					                    				
    			console.log(r)					                    				
    		}
    });
}
function create_new_aliexpress_address(CUSTOMER_DATA_OBJECT) {
	
    var ALIEXPRESS_SHIPPING_ADDRESS_URL = 'https://ilogisticsaddress.aliexpress.com/ajaxSaveOrUpdateBuyerAddress.htm';
    var crs = parse_the_csrf_token();
    
    CUSTOMER_DATA =	{   contactPerson: 'sat singh',
                        mobileNo: '9876543210',
                        phoneCountry: 'in',
                        country: 'in',
                        province: 'punjab',
                        city: 'mohli',
                        address: 'Its a test address 1',
                        address2: 'test address 2',
                        zip: '160055',
                        isDefault: true,
                        features: {"locale":"en_US"},
                        _csrf_token_: crs,

    };

    CUSTOMER_DATA =	{   _csrf_token_: '1dfhj68ra4fzb',
                        phoneCountry: '+91',
                        contactPerson: 'test',
                        mobileNo: '9876543210',
                        address: 'test address 1',
                        address2: 'test address 2',
                        zip: '160055',
                        country: 'IN',
                        province: 'Punjab',
                        city: 'mohali',
                        features: '{"ruPassport":"taxNumber","locale":"en_US"}',
                        shipcompany: 'Other',
                        useLocalAddress: true
    };



    setTimeout(() => {
        

	
        $.ajax({ 
            url : ALIEXPRESS_SHIPPING_ADDRESS_URL,
            method : 'POST',
            data : CUSTOMER_DATA,
            beforeSend: function(xhr){
                xhr.setRequestHeader('Accept','application/json, text/plain, */*')
                xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')

            },
            success : function(res){
                console.log('Address successfully created.');

                setTimeout(() => {
                    // window.location.reload();
                }, 2000);
                

            },
            error : function(a,b){
                console.log(a)
                console.log(b)
            }
        });
    }, 2000);
    
}