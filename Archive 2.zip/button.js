

var div=document.createElement("div"); 
	document.body.appendChild(div); 
	// div.createElement=("button");
	div.innerHTML="<button id='import-product' style='float: right; margin-right: 100px; height: 55px;border-radius: 30px; position: fixed; bottom: 17px;right: 0;'>clicked</button>";
		// console.log('load')