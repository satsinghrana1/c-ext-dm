// js fo view 1 oreder page



						if($(".sa-address-row").length!=0) {

							document.getElementsByClassName('sa-order-add-a-new-address')[0].click();


							$("input[name=contactPerson]").val(jsonObj.contactPerson);								

							var country = document.getElementsByName("country")[0];								
								country.value = jsonObj.country;						
							
							var event   = new Event('change');
								
							country.dispatchEvent(event);										
							
							$("input[name=address]").val(jsonObj.address1);									
							$("input[name=city]").val(jsonObj.city);									
							$("input[name=zip]").val(jsonObj.zip);

							$("input[name=phoneCountry]").val(jsonObj.country_code);
							$("input[name=mobileNo]").val(jsonObj.phone_number);
							
							setTimeout(function(){

								$("input[name=province]").val(jsonObj.province);
								$("input[name=province]").next().val(jsonObj.province);

								order["ifOP"] 	= 0;
								order["first"] 	= 0;
								order["second"] = 0;
								order["third"] 	= 1;

								chrome.storage.sync.set(order);


								document.getElementsByClassName('sa-confirm')[0].click();

							},1000);

						}else {
							/*
							 * FILL CUSTOMER DETAILS
							 */
							 console.log('FILL DETAILS')
							 var name = "test name";
							 var phoneCountry = "91";
							 var mobile = "9876543210";
							 var country = "india";
							 var state = "punjab";
							 var city = "mohali";
							 var zip = "160055";
							 
							 var country_indexing = [{"country":"Afghanistan","ali_index":0},
							 						 {"country":"Aland Islands","ali_index":1},
							 						 {"country":"Albania","ali_index":2},
							 						 {"country":"Algeria","ali_index":4},
							 						 {"country":"Andorra","ali_index":6},
							 						 {"country":"Angola","ali_index":7},
							 						 {"country":"Anguilla","ali_index":8},
							 						 {"country":"Argentina","ali_index":10},
							 						 {"country":"Armenia","ali_index":11},
							 						 {"country":"Aruba","ali_index":12},
							 						 {"country":"Australia","ali_index":14},
							 						 {"country":"Austria","ali_index":15},
							 						 {"country":"Azerbaijan","ali_index":16},
							 						 {"country":"Bahamas","ali_index":17},
							 						 {"country":"Bahrain","ali_index":18},
							 						 {"country":"Bangladesh","ali_index":19},
							 						 {"country":"Barbados","ali_index":20},
							 						 {"country":"Belarus","ali_index":21},
							 						 {"country":"Belgium","ali_index":22},
							 						 {"country":"Belize","ali_index":23},
							 						 {"country":"Benin","ali_index":24},
							 						 {"country":"Bermuda","ali_index":25},
							 						 {"country":"Bhutan","ali_index":26},
							 						 {"country":"Bolivia","ali_index":27},
							 						 {"country":"Botswana","ali_index":29},
							 						 {"country":"Brazil","ali_index":30},
							 						 {"country":"Bulgaria","ali_index":31},
							 						 {"country":"Burkina Faso","ali_index":32},
							 						 {"country":"Burundi","ali_index":33},
							 						 {"country":"Cambodia","ali_index":34},
							 						 {"country":"Canada","ali_index":36},
							 						 {"country":"Cape Verde","ali_index":37},
							 						 {"country":"Cayman Islands","ali_index":39},
							 						 {"country":"Central African Republic","ali_index":40},
							 						 {"country":"Chad","ali_index":41},
							 						 {"country":"Chile","ali_index":42},
							 						 {"country":"Christmas Island","ali_index":43},
							 						 {"country":"Cocos (Keeling) Islands","ali_index":44},
							 						 {"country":"Colombia","ali_index":45},
							 						 {"country":"Comoros","ali_index":46},
							 						 {"country":"Congo, The Democratic Republic Of The","ali_index":47},
							 						 {"country":"Cook Islands","ali_index":49},
							 						 {"country":"Costa Rica","ali_index":50},
							 						 {"country":"Cyprus","ali_index":54},
							 						 {"country":"Czech Republic","ali_index":55},
							 						 {"country":"Denmark","ali_index":56},
							 						 {"country":"Djibouti","ali_index":57},
							 						 {"country":"Dominica","ali_index":58},
							 						 {"country":"Dominican Republic","ali_index":59},
							 						 {"country":"Ecuador","ali_index":60},
							 						 {"country":"Egypt","ali_index":61},
							 						 {"country":"El Salvador","ali_index":62},
							 						 {"country":"Equatorial Guinea","ali_index":63},
							 						 {"country":"Eritrea","ali_index":64},
							 						 {"country":"Estonia","ali_index":65},
							 						 {"country":"Ethiopia","ali_index":66},
							 						 {"country":"Falkland Islands (Malvinas)","ali_index":67},
							 						 {"country":"Faroe Islands","ali_index":68},
							 						 {"country":"Fiji","ali_index":69},
							 						 {"country":"Finland","ali_index":70},
							 						 {"country":"France","ali_index":71},
							 						 {"country":"French Guiana","ali_index":72},
							 						 {"country":"French Polynesia","ali_index":73},
							 						 {"country":"Gabon","ali_index":74},
							 						 {"country":"Gambia","ali_index":75},
							 						 {"country":"Georgia","ali_index":76},
							 						 {"country":"Germany","ali_index":77},
							 						 {"country":"Ghana","ali_index":78},
							 						 {"country":"Gibraltar","ali_index":79},
							 						 {"country":"Greece","ali_index":80},
							 						 {"country":"Greenland","ali_index":81},
							 						 {"country":"Grenada","ali_index":82},
							 						 {"country":"Guadeloupe","ali_index":83},
							 						 {"country":"Guatemala","ali_index":85},
							 						 {"country":"Guernsey","ali_index":86},
							 						 {"country":"Guinea","ali_index":87},
							 						 {"country":"Guyana","ali_index":89},
							 						 {"country":"Haiti","ali_index":90},
							 						 {"country":"Honduras","ali_index":91},
							 						 {"country":"Hungary","ali_index":93},
							 						 {"country":"Iceland","ali_index":94},
							 						 {"country":"India","ali_index":95},
							 						 {"country":"Indonesia","ali_index":96},
							 						 {"country":"Iraq","ali_index":97},
							 						 {"country":"Ireland","ali_index":98},
							 						 {"country":"Israel","ali_index":99},
							 						 {"country":"Italy","ali_index":100},
							 						 {"country":"Jamaica","ali_index":101},
							 						 {"country":"Japan","ali_index":102},
							 						 {"country":"Jersey","ali_index":103},
							 						 {"country":"Jordan","ali_index":104},
							 						 {"country":"Kazakhstan","ali_index":105},
							 						 {"country":"Kenya","ali_index":106},
							 						 {"country":"Kiribati","ali_index":107},
							 						 {"country":"Kosovo","ali_index":109},
							 						 {"country":"Kuwait","ali_index":110},
							 						 {"country":"Kyrgyzstan","ali_index":111},
							 						 {"country":"Lao People's Democratic Republic","ali_index":112},
							 						 {"country":"Latvia","ali_index":113},
							 						 {"country":"Lebanon","ali_index":114},
							 						 {"country":"Lesotho","ali_index":115},
							 						 {"country":"Liberia","ali_index":116},
							 						 {"country":"Liechtenstein","ali_index":118},
							 						 {"country":"Lithuania","ali_index":119},
							 						 {"country":"Luxembourg","ali_index":120},
							 						 {"country":"Madagascar","ali_index":123},
							 						 {"country":"Malawi","ali_index":124},
							 						 {"country":"Malaysia","ali_index":125},
							 						 {"country":"Maldives","ali_index":126},
							 						 {"country":"Mali","ali_index":127},
							 						 {"country":"Malta","ali_index":128},
							 						 {"country":"Martinique","ali_index":130},
							 						 {"country":"Mauritania","ali_index":131},
							 						 {"country":"Mauritius","ali_index":132},
							 						 {"country":"Mayotte","ali_index":133},
							 						 {"country":"Mexico","ali_index":134},
							 						 {"country":"Monaco","ali_index":137},
							 						 {"country":"Mongolia","ali_index":138},
							 						 {"country":"Montenegro","ali_index":139},
							 						 {"country":"Montserrat","ali_index":140},
							 						 {"country":"Morocco","ali_index":141},
							 						 {"country":"Mozambique","ali_index":142},
							 						 {"country":"Myanmar","ali_index":143},
							 						 {"country":"Namibia","ali_index":144},
							 						 {"country":"Nauru","ali_index":145},
							 						 {"country":"Nepal","ali_index":147},
							 						 {"country":"Netherlands","ali_index":148},
							 						 {"country":"Netherlands Antilles","ali_index":149},
							 						 {"country":"New Caledonia","ali_index":150},
							 						 {"country":"New Zealand","ali_index":151},
							 						 {"country":"Nicaragua","ali_index":152},
							 						 {"country":"Niger","ali_index":153},
							 						 {"country":"Nigeria","ali_index":154},
							 						 {"country":"Niue","ali_index":155},
							 						 {"country":"Norfolk Island","ali_index":156},
							 						 {"country":"Norway","ali_index":158},
							 						 {"country":"Oman","ali_index":159},
							 						 {"country":"Pakistan","ali_index":161},
							 						 {"country":"Panama","ali_index":164},
							 						 {"country":"Papua New Guinea","ali_index":165},
							 						 {"country":"Paraguay","ali_index":166},
							 						 {"country":"Peru","ali_index":167},
							 						 {"country":"Philippines","ali_index":168},
							 						 {"country":"Poland","ali_index":169},
							 						 {"country":"Portugal","ali_index":170},
							 						 {"country":"Qatar","ali_index":172},
							 						 {"country":"Reunion","ali_index":173},
							 						 {"country":"Romania","ali_index":174},
							 						 {"country":"Rwanda","ali_index":176},
							 						 {"country":"Saint Lucia","ali_index":179},
							 						 {"country":"Saint Martin","ali_index":180},
							 						 {"country":"Samoa","ali_index":182},
							 						 {"country":"San Marino","ali_index":183},
							 						 {"country":"Saudi Arabia","ali_index":185},
							 						 {"country":"Senegal","ali_index":186},
							 						 {"country":"Serbia","ali_index":187},
							 						 {"country":"Seychelles","ali_index":188},
							 						 {"country":"Sierra Leone","ali_index":189},
							 						 {"country":"Singapore","ali_index":190},
							 						 {"country":"Slovenia","ali_index":193},
							 						 {"country":"Solomon Islands","ali_index":194},
							 						 {"country":"Somalia","ali_index":195},
							 						 {"country":"South Africa","ali_index":196},
							 						 {"country":"South Sudan","ali_index":198},
							 						 {"country":"Spain","ali_index":199},
							 						 {"country":"Sri Lanka","ali_index":200},
							 						 {"country":"Suriname","ali_index":202},
							 						 {"country":"Swaziland","ali_index":203},
							 						 {"country":"Sweden","ali_index":204},
							 						 {"country":"Switzerland","ali_index":205},
							 						 {"country":"Tajikistan","ali_index":207},
							 						 {"country":"Thailand","ali_index":209},
							 						 {"country":"Togo","ali_index":211},
							 						 {"country":"Tonga","ali_index":212},
							 						 {"country":"Trinidad and Tobago","ali_index":213},
							 						 {"country":"Tunisia","ali_index":214},
							 						 {"country":"Turkey","ali_index":215},
							 						 {"country":"Turkmenistan","ali_index":216},
							 						 {"country":"Turks and Caicos Islands","ali_index":217},
							 						 {"country":"Tuvalu","ali_index":218},
							 						 {"country":"Uganda","ali_index":219},
							 						 {"country":"Ukraine","ali_index":220},
							 						 {"country":"United Arab Emirates","ali_index":221},
							 						 {"country":"United Kingdom","ali_index":222},
							 						 {"country":"United States","ali_index":223},
							 						 {"country":"Uruguay","ali_index":224},
							 						 {"country":"Uzbekistan","ali_index":225},
							 						 {"country":"Vanuatu","ali_index":226},
							 						 {"country":"Venezuela","ali_index":228},
							 						 {"country":"Vietnam","ali_index":229},
							 						 {"country":"Yemen","ali_index":233},
							 						 {"country":"Zambia","ali_index":234},
							 						 {"country":"Zimbabwe","ali_index":236}];

							$(document).find("#contactPerson").val(name);	
							
							var ali_country_index = 0;
							
							$.each(country_indexing, function(index, data){
								
								if (data.country == jsonObj.country) {
									ali_country_index = data.ali_index;								
								}
								
								
							});
							
							// $(document).find("#phoneCountry").val(phoneCountry);	
							// $(document).find("#mobileNo").val(mobile);	
							// $(document).find("#address").val(country+' '+state+' '+city+' '+zip);	
							// $(document).find("#zip").val(zip);	
							
							
							
							$('.country-item').trigger('click');
							
							$.each($('.next-menu.zoro-ui-select-dropdown.zoro-ui-search-select-dropdown').find("li"), function(index, data){
								
								
								
								if (index == ali_country_index) {
									$(data).trigger('click');
								}
								
								
							});
							
							
							// $('input[role="searchbox"]').val('india');
							
							// $(document).find('.next-select.next-select-auto-complete.next-size-medium.next-search-input').find('input').val('india');
							
							// $('.css-flag.css-us').
							
							// $(document).find('.next-overlay-wrapper.opened ul li').eq(30).trigger('click');
							
							/*							

							var country = document.getElementsByName("country")[0];								
								country.value = jsonObj.country;
							
							var event   = new Event('change');
								
								country.dispatchEvent(event);										
								
								$("input[name=address]").val(jsonObj.address1);									
								$("input[name=city]").val(jsonObj.city);									
								$("input[name=zip]").val(jsonObj.zip);
								// $("input[name=mobileNo]").val('9876543210');

								$("input[name=phoneCountry]").val(jsonObj.country_code);
								$("input[name=mobileNo]").val(jsonObj.phone_number);

								order["ifOP"] 	= 0;
								order["first"] 	= 0;
								order["second"] = 0;
								order["third"] 	= 1;

								chrome.storage.sync.set(order);
								
								setTimeout(function(){

									$("input[name=province]").val(jsonObj.province);
									$("input[name=province]").next().val(jsonObj.province);
									
									document.getElementsByClassName('sa-confirm')[0].click();

								},1000);
								*/
													
						}