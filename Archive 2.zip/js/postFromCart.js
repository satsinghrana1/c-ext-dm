chrome.storage.sync.get("first", (order) =>{

	console.log('/*--------------*/')
	console.log(order)
	console.log('/*--------------*/')


	if(order["first"] == 1){
		var order = {};
		order["ifOP"]   = 0;
		order["first"]  = 0;
		order["second"] = 1;
		order["third"]  = 0;
		chrome.storage.sync.set(order);
		setTimeout(function(){
			$(".buy-now")[0].click()
		}, 3000);
	}
});