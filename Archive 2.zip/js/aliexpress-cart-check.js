/**
 * Dropmarket extension process workflow.
 * Developer : Sat Singh Rana
 * Date : 05-08-2019
 */
window.addEventListener("load", pageFullyLoaded, false);   
function pageFullyLoaded(){
    $(function() {
        console.log( "Ready! Aliexpress-cart-check.js" );
        
        setTimeout(() => {
            
            $.ajax({
                url : 'https://shoppingcart.aliexpress.com/api/1.0/cart.do',
                method :'GET',
                beforeSend: function(xhr) {                    
				    xhr.setRequestHeader('content-encoding' , 'gzip');
				    xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                },
                success: function(res){

                    var products_in_cart = res.captain.quantity;
					var item_ids = [];	
                    
                    if (products_in_cart>0) {
                        $.each(res.stores, function(indexStore,dataStore){      		
                            $.each(dataStore.storeList, function(indexstoreList,datastoreList){
                                $.each(datastoreList.products, function(indexdatastoreListproducts,datastoreListproducts){
                                    item_ids.push(datastoreListproducts.itemId);									
                                });
                            });
                        });

                        // delete_the_cart_items(item_ids);


                        chrome.storage.sync.get(null, function(params) {
                            console.log(params);
                        });

                    }
                        


                },
                error : function(err,e){
                    console.log('err : ',err);
                    console.log('e : ',e);
                }

            });

        }, 2000);





    


    });
}

// Get the Aliexpress CSRF token
function parse_the_csrf_token(){
	var crs =  null;				
	var e = !0,
	t = !1,
	r = void 0;
	for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) 
	{
	    var i = n.value, a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
	    
	    if (null !== a) {
	    	crs =  a[1]
	    }
	}
	return crs;	
}
/**
 * Delete cart Items.
 */
function delete_the_cart_items(item_ids){
    console.log('items to be deleted :', item_ids);
    // Get the _csrf_token_			
    var token = parse_the_csrf_token();			
    
    var items_data = [];
    
    $.each(item_ids, function(i,d){
        items_data.push({itemId : d, quantity:0});
    });

    var prm = '{"updates":'+JSON.stringify(items_data)+',"action":"DELETE_ITEMS","selected":"","_csrf_token_":"'+token+'"}';
    var url = "https://shoppingcart.aliexpress.com/api/1.0/cart.do";
    var xhttp = new XMLHttpRequest();  
        xhttp.open('POST', url, true);
        //Send the proper header information along with the request
        xhttp.setRequestHeader('Content-type', 'application/json');
        xhttp.onreadystatechange = function() {
            if(xhttp.readyState == 4 && xhttp.status == 200) {
                console.log('Post request response : ',xhttp.responseText);
                window.location.reload();
            }
        }
        xhttp.send(prm);
}