window.addEventListener("load", pageFullyLoaded, false);

function pageFullyLoaded(){
    $(function() {
        console.log( "Dm-x-order.js --Run" );
        // chrome.storage.sync.clear();return;

        /**------------ Product import process start (Aliexpress) ------------*/

        //Create hover import icon

        // check for the product page
        
        // https://www.aliexpress.com/item/

        if (window.location.href.indexOf('aliexpress.com/item/')>-1) {
            console.log('Product page');

            var product_image = $('.images-view-wrap .images-view-list li img').eq(0).attr('src').replace('_50x50.jpg','');

            var doc  = document;	
            var body = doc.body;	

            //ADD THE CSS OF EXTENSION...
            var css  = '';
                css += '#dropmarket-floating-icon {position: fixed;top: 25px;right: 25px;width: 50px;height: 50px;z-index: 500000;box-shadow: 0 5px 10px #0505056b;border-radius: 50%;}.floating-icon-img{width: 50px;height: 50px;border-radius: 50%;}#dropmarket-floating-icon:hover{opacity:1;cursor:pointer}div#product-importing-notify {position: fixed;top: 25px;right: 21px;z-index: 500000;    box-sizing: border-box;border-radius: 2px;background-color: #ffffff;box-shadow: 0 1px 4px 0 rgba(27, 37, 48, 0.4);padding: 10px;width: 260px;}.notifybox .loading-imgHolder {float: left;width: 40px;height: 40px;margin-right: 10px; overflow: hidden;}.notifybox p {font-size: 12px;color: #26c1c9;text-transform: uppercase;margin-bottom: 7px; margin-top: 0px; line-height: 1.3; font-family: "Roboto", sans-serif;}.img-responsive{width:40px}.notifybox .crossBtn {color: #df1857;font-size: 12px;position: absolute;right: 7px;top: 5px;cursor: pointer;}.notifybox .pro-detail {overflow: hidden;padding-left: 0px;line-height: 17px;}.notifybox .pro-detail span {font-family: "Roboto", sans-serif;font-size: 12px;line-height: 1.67;text-align: left;color: #181f26;display: block !important;display: -webkit-box !important; max-width: 100% !important; height: 34px !important;line-height: 1.38; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden !important;text-overflow: ellipsis !important; white-space: initial !important;}';

                head  = doc.head || doc.getElementsByTagName('head')[0];
                    
            var style 	   = doc.createElement('style');
                style.type = 'text/css';
    
            var fontawsome 	    = doc.createElement('link');
                fontawsome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css';
                fontawsome.rel  = 'stylesheet';

            var googlefont 	    = doc.createElement('link');
                googlefont.href = 'https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900';
                googlefont.rel  = 'stylesheet';
		
                
            if (style.styleSheet){
                // This is required for IE8 and below.
                style.styleSheet.cssText = css;
            } else {
                style.appendChild(document.createTextNode(css));
            }

            head.appendChild(googlefont);
            head.appendChild(fontawsome);
            head.appendChild(style);
            
            var dropmarketIcon        = doc.createElement("div"); 
                dropmarketIcon.id     = "dropmarket-floating-icon";
                dropmarketIcon.style  = ""; 
                
                body.appendChild(dropmarketIcon);

            var html  = "";
                html += "<span id='import-product-floating-btn'><img class='floating-icon-img' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWMAAAFiCAYAAAAjnrlEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAF6tJREFUeNrs3U+MXVd9B/AzowgVt1gOpBZJQUyQgqp6gVtAlUoUG7WRQlGEkdIkK2JLyaJ/pNhythgCyzbyRF2g4ki2s4oBiaAIHClIsSO3XUCKWQwLLJWJqJxUIMc1IQELcN/v3jtz3zyPx+/NvHfPfe9+PtJokpA4M2cu3xx/7/kzlzrsp+9/aKH3aaH6070D//OeBIzb5d7Hjwb+/Hz1x+fvfOPU5a4OzFyHQnd39fHRKoB3+/8FtNKZ3sdy7+O16o87EdIzGcZV+O6rZre7+2a/wHRaroL5bHzuhfOyMG5vAK+E7z7hCzMvqo1v9z6e7wXzeWGcP4Bj1vt4FcA7PJ/Q2Vnz872Pp6d5xjx1YdwL4Ajd/VUImwED/c70Pk72QvmEMJ5cCEfwfrEKYoCNxAu/p3sfi9Py8q/1YdwL4b2priIARhWz5CfbXmG0NoyrmfDxdP36X4CZC+XWhbE6Apig1tYXrQrjXhB/KZWVhJURwCTF7PhQL5CfF8ZrQ3hv79PRZFcc0KwzvY8DbagusoZxtUwtKomDngkgk6grokte7GQYVxs2jpsNAy2aJX8uV5c8nymIYyb8Q0EMtMjeiKfqaIXZnhlXtUTMhq0ZBtosVlscmskwVksAU+ZMarC2aCSMq9US30qWrAHTJU6EO9DEyXATD+NeEO+vZsQA0yhmxp+adCBP9AWeIAZmQPyO/uVJv9ibWBhXu+kEMTArgfytaoI5EROpKXpfcITwfj8/YAYdmMR5yWOfGVdriAUxMKuOT2KGPNaZsY4Y6JA/H+dLvbHNjAUx0DEvV/sn2jMzrr6gH/rZAB0Ty97uHMfGkC3PjKvD4F/2MwE6aGXZ25Y3tG0pjKsvwM46oMuiGTiae2bsQHiAlPZXK8k2bdOdsRd2ANfZ9AqLTYVx9cIuemL1BEBtuQrkkV/obbamOC6IAa6zkDbZH48cxtWZE3pigPXt38yhQiPVFNYTAwxlOY1YV4w6Mz5qjAFuaiGVN9+Pf2Zs9QTAyIZeXTHUzLja3GFWDDCaoXNz2JoiFjNbPQEwmr3DHrd505qiOnvip8YUYFOW73zj1J3jmBl/0VgCbNrCMLPj+SFmxfuNJcCW3HRSO7/VXwCArc+O5zeYFe8wKwZoZna80cz4oLEDGOvseN9mwvgRYwcwVo+PFMZVt7Fg3ADGam+1MGLomfFnjRlAc7Pj+XVmxZHa+4wXwETsG3ZmLIgBJide5O0dJoy9uAOYrEc2DOOqonCLB8Bk7bvZzFhFATB5O6qbk24YxnuMEUAjHjEzBshv77phvN7bPQAmZnd1BtB1M2NhDJBpdtwfxvpigIZnx2bGAPntWRPGg0ssAGjE3sGZ8YIxAWjeyiluK2FsZgyQx5ow/qjxAMhib38Y7zAeAFl8qD+M9xoPgCwW+sMYgDyKZmLesjaArHavzIz1xQCZqSkAMosDgyKMFwwFQFa7hTFAC6gpAFrgFkMwmp3Hn0jz27d19vt/+8UfpCvHvutBAGGc16//48fpvV/+fGe//z/4qz8rxuDq0rKHAcZITTGimBVGGHX7dweHe787+EMPAwjjvH5x8Kvp91fe7u5vpz74x2nHEw94EEAY5/Xbn/28873p9sc+nbbd9wkPAwjjvC7/yzfT1aXXOj0Gtz399+oKEMb5/eLxr3b74dm+rQhkQBhnFSsKLj/1zU6Pwbb7Pp62P/a3HgYQxnmpK1LxMu9duxY8DCCM81JXqCtAGLdA1BVXjp3u9Bi8a9eHLHcDYZxf1BWx5K3Ldhx+oNihBwjjbH5/5VfFZpCuu23RcjcQxpnFNumu1xWxO6/LZ3eAMG4JdUVKf/TQHrvzQBjnpa4oxeqKmCUDwjibqCvi3N9OP1ix3G3RcjcQxpnF2uMun+wWYmWF3XkgjLMq6orH1RXxMs/uPBDGWb394vc7X1cEu/NAGGenrih35733y494GEAY5xN1xaUjJzs/DnEYvd15IIyzeuvU2c7fmxfKm7XtzgNhnFHX780rHjanu4Ewzi125cXuvK6Lw+hjhx4gjLOJS0zVFal4mWd3HgjjrNQVdueBMG4BdUUpVlY4jB6EcVZRV3T93rwQh9HbnQfCOCtbpUs7jx+23A2EcT5xb97lp9QV8SJPXQHCOKvojtUV5e48h9EjjMlKXVGKzSDqCoQx2agrqgfR7jyEMbld+drpzt+bF2J3nsPoEcZk4968WrzMszsPYUw2sU36yrHTHsjt24rT3UAYk02srlBXlIfRW+6GMCYbdUUtduc5jB5hTDZRV8Rh9KTiMCHL3RDGZHPpyLOdP9ktxIu8uF0ahDFZFHWFzSCFOIje7jyEMdm8/eL3ex8/MBDJ7jyEMZnF7FhdsbLc7bAHAmFMHuqKWqyssDsPYUw2UVe4N68UL/McRo8wJhv35tUcJoQwJhv35tVid17cLg3CmCzi3jx1RSkOo7c7D2FMNuqKmt15CGOyUVfUYnee/hhhTDZRV7g3rxSH0ccOPRDGZGHtcS1e5jmMnpn43Z4hmD5xb97rZ19N83/6AYPRs/2r/5Te9Zvfdfb7j/cI5W7NX3kYhDGNevjudHXhtpR+/WtjceFi+s0/PpM+8P1/LbZNd/d3CJ93FvaUU1NMm9tvTXOP/o1xqFz7yjdsG09OtxPGNG7uCw/2/p/3bgMRnvleSj+5WPyhU+6cbieMac7Dd6f0Fx82DuHCxXTtmZfW/KVLR052eh220+2EMU1QT6wR9cQg67CdbieMmbi5Q/erJ1acOrdaTwyybTwVN2s73U4YMwl7dqV0zy7jEF5/M12LrngDXd82HnWF3YnCmHF7z7vT3Bf+zjhUrn3l6yn98p0N/x51RXm6XcyQEcaMSRHE6olS1BP/9d9D/a3qipR2HH7A6XbCmLFQT9SGqCcGXTrybOeHzel2wpitUk+sMUw9MSi2jV9+qtt1hdPthDFbVCxjU0+UvvPq0PXEoOiOu37KXZxuZ3eeMGYzYmPHQ3cbh/DWO+na4gtb+iWcclfuznO6nTBmFEU98aBxqBSbO0asJwapK6rlbovqCmHM0Ip64vZbDUR4ZSmls0tj+aWiroglb11md54wZljqiVrUE+tsed4KR0yWR23anSeMudmsWD2xahz1xKBYd3zl2OnOj63T3YQxGwXxo/eqJ1bEyokx1ROD1BV25wljbuwjd6TkRLZSUU98fWK/fHEQvboibX/s03bnCWOumxXb3LGq2GX3+psT/XeoK0o7jz+hrhDGrAZx1BN33WEgQtQTz51r5F+lrnC6mzCmpp6oTbieGBR1hbMryt15cX8ewrjbs+KD9xuEShP1xCD35pXe++VH7M4Txh3mPrvahYuN1RODYqt0lw+iL0KguDvvCc+hMO4g99mtnRWPeXPHKIrVFc6usNxNGHdTsbnDiWylqCducJ9dU9QVpTiM3u48Ydwd6onahYvp2jMvteJLUVeUdh4/bLmbMO4A9cQaOeuJQVFXdP3evBAv8tQVwnjmqSf6tKCeGOTevFLsznMYvTCeXXGfnXqiFPfZnTrXyi8ttkqrKxwmJIxnlfvs1tjMfXZNiV156oqV5W6HPazCeLYUQayeKMWMeJP32TVFXVFyGL0wni1RT9yzyziEqCeiK54CTnYrxcs8y92E8fRTT6zR5npiUFFXPKWucJiQMJ4JxdkT6onSd15tfT0xKLrjq0uvdf5HZ3eeMJ5usXLiMx8zDiFOZFt8YSq/dFulS7E7z2H0wnj6FPWE++xWTOI+u6ZcXVpWV1RuW7TcTRhPmWKXnfvsSq8sTew+u6aoK0qxOy9ul0YYT4eoJx662ziE4sD4b8zEt3LpyEk/z544iN7uPGHcfuqJNaa5nhjk3rxarK5wGL0wbrW5mBGrJ0ozUE8Mcm9eFRqx3G3Rcjdh3Fbus6tFPXH0hZn7toqD6G0GKdidJ4zbOyu2uWNVjvvsmqKuqMXLPLvzhHG7gvjRe1O66w4DEWJjx3PnZvpbVFfU7M4Txu2hnqgVqye+PvPfZtQVl4486+edyt15cbs0wjj/rFg9sWqW64lB7s2rxWH0ducJ47ziPjv1RKkD9cQg9+bVdh5/wu48YZyJ++zWzooXX+jc91ysrnB2RRkkTncTxrm4z65PC++za4q6orbtvo8XO/QQxs2JesJ9dqULF9O1Z17q9BCoK2rxMs/uPGHcDPXEGrNy9sRWlKsrnF1RBIrdecK4KeqJPh2uJwa9deqse/MqsbLCYfSju8UQjOaDf/2XxX/9u+rKmfPp0j9Xa4mn7OaOSfvf0/+Z0p9YUVD48PuMgZnxZHX97fn2vbvTtp3vE8SD4oCohz9pHCpd2PwjjDPz9rzcAmtN6Vrqqz4d2vwjjFswO+7y23NrSgdYXVOzukYYN8li/3JNqSMUk9U1A6yuEcaNi7qi62/P4415149QVE/0sbpGGOcSB42rKzpcV6gnauoJYZxTnGkbZ9t2WRyh2Mk1pXHfoXpi1Sze7CKMp8yVY99VVxx+oHNHKBZHp6onSqfOWeoojNuh63VFiC2wnVnutmdXSvfs8uCH198sz7FGGLeBuiIVh8PEnWgzL+oJFwqsKjZ3/PIdAyGM2yPqiqtLr3V6DOL4xG33fWKmv0f1RB/1hDBuKweNl7vzZvYIRfVETT0hjNvs6tJyuvxUt+uKmT1CMeqJg/d7yCvqCWHcetEdd72uiJUVs7Y7r1jGFocBkdIrS+oJYTwd1BWpeJk3M7vzYmPHQ3d7sMNb79jyLIynh7qiNBO784rVEw96qCtFEKsnhPE0ufK108WSty6L3XlxJ9o0U0/0iXri7JJxEMbTpTjZ7aC6Yvtjn57e3XnqiZp6QhhPs9gmfeXY6c6Pw7Tuzps7ZPXEiuLsCfWEMJ5msbqi63VFrDuetv547tF7U7rrDg9wiJUT33nVOAjj6aauKMVh9LFDbyp8pBfCTmQrFfWE++yE8YyIuiKucu+6eJk3DbvznD1Ru+Y+O2E8ay4debbzJ7tNw+489USfqCeeO2cchPFscW9eKVZWtPYw+ljCpp4oqSeE8SyLe/PefvEHnR+HOIy+jbvzbO7o89y/qyeE8WyL2XHX64oQqytatdzNfXY199kJ4y5QV5RadXfe7be6z66PzR3CuDPUFaXYndeGw+iLesKB8aVYPfGTi8ZBGHfHpSMn1RWpBXWFeqKmnhDGXeTevOoBjOVuuXbnxYls6olV6glh3Flxb15sCOm62J2X4zB699n1ifvs1BPCuMtiq7S6IhUv8xrdnec+u5r77IQx6orVB3H7trTz+BPN/MuKA+NteV7hPjthTEVdUWpquZt6ok/UE+6zE8bU4uwKyt15Ez2MXj1RU08IY67n3rzaxA6jV0+soZ4QxtxAdMdXl17r/DjEi7y4XXrcimVs6olS3GennhDG3Jit0qU4iH6su/PcZ1dzn50w5ubUFbWx7c4r6gknsq0oglg9IYy5OffmVQ9nsdzt8JZ/naKeiLOKKeuJs0vGQRgzLPfmlWJlxZZ256knauoJYczoYt3xlWOnDURKxcu8zR5Gr56oqSeEMZukrqht5jCh4j479UQpVk6oJ4Qxm1McRK+uKMTuvLhdemgfucN9divcZyeM2Tp1RS0Oox92d57NHbVil5377IQxWxd1hZPdSsPszivqibvuMFgh6onnzhkHYcw4uDevFrvzNuyP1RM19YQwZvzcm1eLw+hvtDtv7uD9BqiinhDGTEjMjtUVpZgdX3cYvfvsahcuqieEMZOiruh7cOPuvMW+uuL2W91n1z8rtrlDGDNZ6oparKxYOYy+2NzhRLZS1BPus5s6txiC6XPpyMkiiGJ22HVxGP1b6Xfpd+qJ0oWL6dozLxkHYUwTfnv5rfSzH//E7rKV35L/z89T+od/MxDBCzthTHPm4uAbQVyyjpYZoTOeNtbR1qyjRRiTbVZsm+8q62gRxuQJYtt8a+oJhDFZqCdq6gmEMdlmxeqJVeoJhDF5xDZf9UTJNl+EMVnY5rt2VmybL8KYHGzz7WObL8KYLJxCVrPNF2FMFuqJNdQTCGOyUE/0UU8gjMlizy71xIrX31RPIIzJ4D3vtqa4j80dCGOyKIJYPVE6da7c9gzCmEZFPXHPLuMQinrie8YBYUzD1BNrFPXEL98xEAhjmlVcMa+eKKknEMZkESsnPvMx4xDiRDb1BMKYxhX1xIPGoVJs7lBPIIxpWrHLzn12pVeWUjq7ZBwQxjQs6om4XJTqwHhbnhHGNE09sYZ6AmFMFnMxI1ZPlNQTIIyzcJ9dLeqJoy8YB4SxIcgwK7a5Y5X77EAY5wniR+91n92K2NjhPjsQxo1TT9SK1RNOZANhnGNWrJ5YpZ4AYZwniNUTNfUECOMsYgnbw580Diuz4kWrJ0AY55gVu8+u5j47EMZZPHy3++xWXLjoPjsQxhncfmt5EBAFZ0+AMM5CPdFHPQHCOIs4LF49USrus1NPgDBuWpzIduh+41CxuQOEcRbF5g71RMl9diCMs9izK6V7dhmHUNQT7rMDYdy04sB4W55XFPWEA+NBGDdNPdFHPQHCOItYOaGeKKknQBhn4T67NYqzJ9QTIIybVuyyc59dyX12IIyziHoiLhelOjDelmcQxk1TT6xRBLF6AoRx09QTfdQTIIyziPvs1BMl9QQI42yzYps7VhXL2NQTIIwbD2L32dXcZwfCOIuoJxwYXyrqCSeygTDOMStWT6wq6onX3zQQMAa3GIIRA+iom41XOXsChLEAAmZJ1BSXDQNA/jA+bxgAsrrsBR5AZne+ceq8MAZoATUFQF7Fe7v53vTYCzyAfM6vzIzDsvEAyDgzFsYAWf2oP4z1xgB5LPeH8WvGAyB/GJsZA2Rw5xunzqyG8cqfANCo1Ynw/Hp/EQBhDNAVZ9cL47PGBSD/zPiMcQFozHIcEHRdGPf+4nJSVQA0Zc0EeH6j/xGAiTm7URh/2/gANOL5G4Zxtd7YKW4AEw7iwRMz52+W1gCM3XUtxHphfNI4AUx2ZnzTMK6qimVjBTCZIF7vUo8b3YFndgwwGevm643C+ITxAhi72Ojx/NBhXG0AEcgADcyKN5oZb/gPATCy6IkXRw7j6kXeGeMHMBbrvrgbZmYcnjR+AGOxYZ5uGMZmxwBjcaJ6F7e5MDY7Bpj8rHioMDY7BthaEN9sVjzszNjsGGBzNlxBMXIYV7PjE8YVYORZ8VAnYc6P8IseSo7XBBjW+V4QLw77Nw8dxlW6qysAhp/ADm2UmXGqUv6MMQbY0GJV704mjCsHkroC4EaW0yZahJHDuFqioa4AWN/nhn1pt9WZ8Upd4XomgLVi9cT5zfyD81v4lx5IbgQBWHGmF8Rf2uw/vOkwrqbhnzP+AGnLebiVmXGqpuMH/ByAjgfxpzbTE48tjKtAPpGG3O4HMIMObbYnHmsYV4Eci5tP+JkAHfNkNSHdsvkxflERyOf9bICOOLGVF3aD5sb5lf30/Q/t6H16ufex288JmPEgHuv7srlxf4UCGRDELQhjgQwI4paEsUAGBPFo5if1C1dr7j6VnPIGCOJ8M+OBWfLx3qf9fp7AFDo0yiHxrZsZD8yS478oTnoDpkn87v5AE0Hc2My4b4a8r/cpZsk7/JyBFltO5VGYje2dmGv6O+wF8kLv07eSF3tAOz1fzYgbvURjLtd32wvlo71PB/3cgRY51FQt0ZowrgJ5bzVLVlsAOZ2vZsPZjnSYyz0C1XrkmCXv9zwAGTw5zjMmpjaMB2bJ8XJvwbMBNOBMNRtebsMXM9e20emFcvwX6vGkugAmI8I3uuFW3eM518aRqqqLLyYv+IDxidURT7ehkpiaMO4L5YUqlPd7joCthHDvY7Hp5WozE8YDofx4FcrqC2AYy72Pk20P4akK475Q3lEFcgTzgmcNWMeZCOFxXYckjG8ezHt7nx7pfewzWwaz4FTunHu6LasjOhPGA8EcgfxZwQydC+CYBX+7bSsjOhvG68yYI5jjs/MvYLZE+J6NWXDO3XLCePRg3tEXynuqz2bOMD0z3wjcH0UI98L3zCx/s3Nd++lWAR2hvFB9fCjVLwOFNTTnchW2qfr8f9Xny7MevOv5fwEGAMjmjanXdVzIAAAAAElFTkSuQmCC'></span>";

            // WHEN PAGE IS FULLY LOADED.
            
            doc.getElementById('dropmarket-floating-icon').innerHTML = html;


            $(document).on("click", ".floating-icon-img", function(){

                
                var scripts         = document.getElementsByTagName("script");
                var product_options = null;
                var variant_data    = null;
                var product_url     = window.location.href;
                var product_specification = '';



                $('body').find('.product-extend .detail-tab-bar .tab-item').eq(2).click();


                var specification = $('.product-specs .product-specs-list li');
                    
                product_specification += '<ul>';
                    
                $.each(specification, function(a,d){

                        
                    var title = $(d).find('.property-title').html();
                    var desc  = $(d).find('.property-desc').html();

                    product_specification += '<li>';
                        product_specification += '<b>'+title+'</b>';
                        product_specification += desc;
                    product_specification += '</li>';

                });

                product_specification += '</ul>';



                $('body').find('.product-extend .detail-tab-bar .tab-item').eq(0).click();


                var product_title      = $('.product-title').text();
                var product_main_image = $('.images-view-wrap .images-view-item').eq(0).find('img').attr('src').replace('_50x50.jpg','');


                var product_id       = null;
                $.each(scripts, function(index,script){

                    var paragraph        = $(script).text();
                    var regex            = /("productSKUPropertyList":.*?\"warrantyDetailJson\")/g;
                    var found            = paragraph.match(regex);
                    var regex_product_id = /("productId":.*?,")/g;
                    var found_product_id = paragraph.match(regex_product_id);

                    // console.log(found_product_id);

                    if (null != found_product_id) {
                        product_id = found_product_id[0].replace('"productId":','').replace(',"','');                        
                    }
                    // console.log(product_id);

                    if (null != found) {

                        var data = found[0].replace('"productSKUPropertyList":','');
                            data = data.replace(',"warrantyDetailJson"','');           

                        var part_1 = data.substring(0,data.indexOf(',"skuPriceList"'));
                        var part_2 = data.substring(data.indexOf('"skuPriceList"'), data.length);

                        product_options = JSON.parse(part_1);
                        variant_data    = JSON.parse('{'+part_2+'}');

                    }else {

                        var regex = /("skuPriceList":.*?\"warrantyDetailJson\")/g;
                        var found = paragraph.match(regex);

                        if (null != found) {
                            var data = found[0].replace('""skuPriceList":','');
                                data = data.replace(',"warrantyDetailJson"','');
                            variant_data = JSON.parse('{'+data+'}');
                        }

                    }

                });
                

                console.log(product_options)

                var variant_has_image  = true;
                var image_option_index = null;

                var variant_images  = [];

                for (let index = 0; index < product_options.length; index++) {
                    var data = product_options[index].skuPropertyValues;                   
                    console.log( data );
                    // Loop through all the properties to check if its an Image.
                    for (let index_2 = 0; index_2 < data.length; index_2 ++) {
                        var data_2 = data[ index_2 ];
                        console.log( data_2.skuPropertyImagePath )
                        if (data_2.skuPropertyImagePath != undefined) {
                            image_option_index = index;

                            variant_images[ data_2.propertyValueIdLong ] = data_2.skuPropertyImagePath;
                            // break;                            
                        }
                    }
                }


                return;

                console.log('image_option_index --> ' + image_option_index);
                console.log('image_option_index --> ' + variant_images);

                var product_has_variant_images = false;

                if (image_option_index != null) {
                    product_has_variant_images = true;                    
                }

   
                

                return;


                var product_images = [];

                $.each($('.images-view-wrap .images-view-item img'), function(i,d){

                    var src = $(d).attr('src').replace('_50x50.jpg','') ;
                    product_images.push( src)

                });


                var variant_images = [];


                // console.log(product_options_final);
                console.log('product_options_final.length -->>>',product_options_final.length);

                for (let index = 0; index < product_options_final.length; index++) {
                    // console.log(product_options_final[index]);

                    $.each( product_options_final[index], function(i,d){
                        console.log(i)
                        console.log(d)

                        for (let ind = 0; ind < d.length; ind++) {

                            if (d[ind].is_image == 'no') {
                            
                                console.log('no image available.')
                            }else{
                                console.log('image available.')
                            }


                        }


                    });

                    
                }
                return

                // $.each(product_options, function(i,d){




                //     console.log(d.skuPropertyValues);


                //     $.each(d.skuPropertyValues, function(i2,d2){



                //         console.log( 'd2.skuPropertyImagePath ->>>>', d2.skuPropertyImagePath )
                //         if(undefined != d2.skuPropertyImagePath){
                //             variant_images[ d2.propertyValueId ] = d2.skuPropertyImagePath;
                //         }

                //     });



                // });




                console.log(variant_images)


                $.ajax({
                    url : 'https://app.dropmarket.net/product-import/import-aliexpress-product.php',
                    method : 'POST',
                    data : { product_url           : product_url,
                             product_main_image    : product_main_image,
                             product_specification : product_specification,
                             variant_data          : variant_data,
                             product_options       : product_options,
                             product_title         : product_title,
                             product_id            : product_id,
                             product_images        : product_images,
                             product_weight        : null,
                             variant_images        : variant_images
                    },
                    beforeSend : function(xhr) {
                        
                    },
                    success : function(response) {
                        // console.log(response);
                        
                    },
                    error : function(e,x){

                    }
                });


                return
                

                


                chrome.storage.sync.get("installId", (items) => {
        
                    installId = items["installId"];
    
        
        
                    if (installId == undefined || installId == 'null' ) {
        
                        importingHtml = '<div class="notifybox">';
                            importingHtml += '<span class="closeNotify crossBtn">';
                                importingHtml += '<i class="fa fa-times"></i>';
                            importingHtml += '</span>';
                            importingHtml += '<p class="importing-message"><i class="fa fa-spinner fa-spin" style="font-size:15px"></i> IMPORTING PRODUCT</p>';
                            importingHtml += '<div class="loading-imgHolder">';
                                importingHtml += '<img class="importing-product-img img-responsive" src="'+productImageSrc+'" />';
                            importingHtml += '</div>';
                            importingHtml += '<div class="pro-detail">';
                                importingHtml += '<span class="loading-product-title">'+productTitle+'</span>';
                            importingHtml += '</div>';
                        importingHtml += '</div>';
        
                        $("body").append("<div id='product-importing-notify'>"+importingHtml+"</div>");
                        $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                        $(".loading-product-title").text('Please login to dropmarket.');
                        
                        return;
                    } else {

                        var specification   = $('.product-specs').html();
                        var product_details = $('.product-main-wrap').html();
                        var scripts         = $('script').html();
                    

                    }
        
                    
        
                    var data = { html 				 : markup, 
                                 vendor 			 : vendor, 
                                 installId 			 : installId,
                                 product_url 		 : url,
                                 mainImage   		 : productImageSrc,
                                 variantImagesStatus : variantImagesStatus
                                };
                                
                    /*
                     * VIEW VERSION CHECK FOR ALIEXPRESS PRODUCTS
                     */
                     
                    
                    var url_parts = url.split('item');
                            
                    console.log( url_parts );
                            
                    productImageSrc = $(".images-view-list img").eq(0).attr('src');				
                            
                    var modified_url = url_parts[0]+'item/product-title'+url_parts[1];
                            
                    console.log(modified_url);
                            
                    data = { html 				 : null, 
                             vendor 			 : vendor, 
                             installId 			 : installId,
                             product_url 		 : modified_url,
                             mainImage   		 : productImageSrc.replace('_50x50.jpg', ''),
                             variantImagesStatus : null,
                             server_crawling_needed : 1
                            };
                                    
                        productTitle    = $(".product-title").text();
                            
                        
                        
                    
        
                    console.log("Before ajax call");
                    console.log(data);
                    
                    return;
                    
        
                    $.ajax({url:"//app.dropmarket.net/aliRequests/new-crawling.php",
                            method:"POST",
                            data: data,
                            beforeSend :function(){
        
                                console.log('show the pop up of product import');
        
                                importingHtml = '<div class="notifybox">';
                                    importingHtml += '<span class="closeNotify crossBtn">';
                                        importingHtml += '<i class="fa fa-times"></i>';
                                    importingHtml += '</span>';
                                    importingHtml += '<p class="importing-message"><i class="fa fa-spinner fa-spin" style="font-size:15px"></i> IMPORTING PRODUCT</p>';
                                    importingHtml += '<div class="loading-imgHolder">';
                                        importingHtml += '<img class="importing-product-img img-responsive" src="'+productImageSrc+'" />';
                                    importingHtml += '</div>';
                                    importingHtml += '<div class="pro-detail">';
                                        importingHtml += '<span class="loading-product-title">'+productTitle+'</span>';
                                    importingHtml += '</div>';
                                importingHtml += '</div>';
        
                                $("body").append("<div id='product-importing-notify'>"+importingHtml+"</div>");
                            },
                            success: function(res){
                                console.log('Inside the success');
                                if (res == "already exist in importlist") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('The product is already in your import list.');
                                }
                                if (res == "already exist in store") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('The product is already in your Store.');
                                }
                                if (res == "success") {
                                    $(".importing-message").html('<i class="fa fa-check" style="font-size:15px;margin-right: 3px;float: left;"></i>PRODUCT SUCCESSFULLY IMPORTED');
                                    $(".loading-product-title").text(productTitle);
                                }
                                if (res == "Max product import reached") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('You have reached the max of 500 products in your Import List.');
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown){
                                $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                $(".loading-product-title").text('Somthing went wrong please try again!');
                            }
                    });
                });





                
                var installId       = variantImagesStatus = 0;
                var markup 	        = $(document)[0].body.innerHTML;
                var url             = window.location.href 
                var vendor          = "aliexpress";
                var productImageSrc = $("#j-image-thumb-list img").attr('src');				
                var productTitle    = $(".product-name").text();
                
                // check for the variant images...
    
                variantImagesStatus = $("#j-product-info-sku .item-sku-image").length;
    
                variantsData 		= {};


                



            

                console.log('Product view VERSION : ',view_version);
                
                // return;
                    
                    
                
                
                
        
                console.log("Make ajax call");
        
                return;
        
                chrome.storage.sync.get("installId", (items) => {
        
                    installId = items["installId"];
        
                    console.log("chrome.storage items are : ",items);
        
                    console.log('Install id is :'+installId);
        
        
                    if (installId == undefined || installId == 'null' ) {
        
                        importingHtml = '<div class="notifybox">';
                            importingHtml += '<span class="closeNotify crossBtn">';
                                importingHtml += '<i class="fa fa-times"></i>';
                            importingHtml += '</span>';
                            importingHtml += '<p class="importing-message"><i class="fa fa-spinner fa-spin" style="font-size:15px"></i> IMPORTING PRODUCT</p>';
                            importingHtml += '<div class="loading-imgHolder">';
                                importingHtml += '<img class="importing-product-img img-responsive" src="'+productImageSrc+'" />';
                            importingHtml += '</div>';
                            importingHtml += '<div class="pro-detail">';
                                importingHtml += '<span class="loading-product-title">'+productTitle+'</span>';
                            importingHtml += '</div>';
                        importingHtml += '</div>';
        
                        $("body").append("<div id='product-importing-notify'>"+importingHtml+"</div>");
                        $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                        $(".loading-product-title").text('Please login to dropmarket.');
                        
                        return;
                    }
        
                    
        
                    var data = { html 				 : markup, 
                                 vendor 			 : vendor, 
                                 installId 			 : installId,
                                 product_url 		 : url,
                                 mainImage   		 : productImageSrc,
                                 variantImagesStatus : variantImagesStatus
                                };
                                
                    /*
                     * VIEW VERSION CHECK FOR ALIEXPRESS PRODUCTS
                     */
                     
                    if( vendor == 'aliexpress'){
                        
                        if (view_version == 'v2') {
                            
                            var url_parts = url.split('item');
                            
                            console.log( url_parts );
                            
                            productImageSrc = $(".images-view-list img").eq(0).attr('src');				
                            
                            
                            var modified_url = url_parts[0]+'item/product-title'+url_parts[1];
                            
                            console.log(modified_url);
                            
                            data = { html 				 : null, 
                                     vendor 			 : vendor, 
                                     installId 			 : installId,
                                     product_url 		 : modified_url,
                                     mainImage   		 : productImageSrc.replace('_50x50.jpg', ''),
                                     variantImagesStatus : null,
                                     server_crawling_needed : 1
                                    };
                                    
                                productTitle    = $(".product-title").text();
                            
                        }
                        
                    }
        
                    console.log("Before ajax call");
                    console.log(data);
                    
                    return;
                    
        
                    $.ajax({url:"//app.dropmarket.net/aliRequests/new-crawling.php",
                            method:"POST",
                            data: data,
                            beforeSend :function(){
        
                                console.log('show the pop up of product import');
        
                                importingHtml = '<div class="notifybox">';
                                    importingHtml += '<span class="closeNotify crossBtn">';
                                        importingHtml += '<i class="fa fa-times"></i>';
                                    importingHtml += '</span>';
                                    importingHtml += '<p class="importing-message"><i class="fa fa-spinner fa-spin" style="font-size:15px"></i> IMPORTING PRODUCT</p>';
                                    importingHtml += '<div class="loading-imgHolder">';
                                        importingHtml += '<img class="importing-product-img img-responsive" src="'+productImageSrc+'" />';
                                    importingHtml += '</div>';
                                    importingHtml += '<div class="pro-detail">';
                                        importingHtml += '<span class="loading-product-title">'+productTitle+'</span>';
                                    importingHtml += '</div>';
                                importingHtml += '</div>';
        
                                $("body").append("<div id='product-importing-notify'>"+importingHtml+"</div>");
                            },
                            success: function(res){
        
                                console.log('Inside the success');
                                
                                if (res == "already exist in importlist") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('The product is already in your import list.');
        
                                }
        
                                if (res == "already exist in store") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('The product is already in your Store.');
        
                                }
        
                                if (res == "success") {
                                    $(".importing-message").html('<i class="fa fa-check" style="font-size:15px;margin-right: 3px;float: left;"></i>PRODUCT SUCCESSFULLY IMPORTED');
                                    $(".loading-product-title").text(productTitle);
                                }
        
                                if (res == "Max product import reached") {
                                    $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                    $(".loading-product-title").text('You have reached the max of 500 products in your Import List.');
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown){
        
                                console.log('Inside the error');
                                console.log(jqXHR);
                                console.log(textStatus);
                                console.log(errorThrown);
        
                                $(".importing-message").html("<span style='color: #ca0673;font-weight: bold;'>Error!</span>");
                                $(".loading-product-title").text('Somthing went wrong please try again!');				
        
                            }
                    });
                });
            })






        }




        /**------------ Product import process end (Aliexpress) ------------*/





        /**------------ Product order process start (Aliexpress) ------------*/
            $('body').on('click', "#dm-progress-message", function(){
                $('body #dm-progress-message').fadeOut(500, function() { $(this).remove(); });
            });
            if($.cookie("dm_order_process_cookie") == undefined){
                if (window.location.href.indexOf('aliexpress') == -1) {
                    
                    chrome.storage.sync.remove('dm_order_process_state');
                }
                show_progress_message('You can order products.',2);
            }else{
                show_progress_message('An Order Is In Progress.',2);
            }
            // Add fontawsome CDN
            $('head').append('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');

            $('.orderBtn').click(function(ev) {

                if($.cookie("dm_order_process_cookie") == undefined){
                    
                    show_progress_message('Initializing Order...',1);
                    // set the cookie
                    var date = new Date(); 
                        date.setTime(date.getTime() + (60 * 3000));
                    $.cookie('dm_order_process_cookie', 1, { expires: date });

                    update_order_process_state('dm_order_button_click');

                    var link  = $(this).attr("href");

                    setTimeout(function(){
                        show_progress_message('Redirecting...',1);
                        var id    = $.now();
                        var tempA = "<a id='"+id+"' href='"+link+"' target='_blank'></a>";
                        $('body').append(tempA);
                        setTimeout(function(){
                            $("#"+id)[0].click();                               
                            $("#"+id).remove();
                        },800);
                    },500);
                    
            } else {
                show_progress_message('Please Wait An Order Is Already In Progress...',5);
            }
            });
            var process_state = null;
            chrome.storage.sync.get(null, function(result) {

                console.log(result)
                
                if(result['dm_order_process_state']==undefined){

                    if ($('.loginForm').length==1 || window.location.href.indexOf('orderHistory.php') == -1) {
                        return;
                    }
                    
                    show_progress_message('Extension Is Ready. <br>You Can Order Product Now...',0,2);
                    return;
                }else{
                    $.each(result['dm_order_process_state'], function(key,value) {
                        if(value==1){
                            process_state = key;
                        }
                    });
                }        

                if (false == process_state) {
                    show_progress_message('No process state found!...');
                    return;
                }else{
                    if (window.location.href.indexOf('login.aliexpress') > -1) {
        
                        show_progress_message('Login To Your Aliexpress Account.<br>Order Process Will Continue...',0,3);

                        return;            
                        
                    }
                    if ( process_state == 'dm_order_button_click' ){

                        if (window.location.href.indexOf('app.dropmarket.net/order-product.php') > -1) {
                            
                            update_order_process_state('dm_set_order_cookie');

                            show_progress_message('Getting order detail.');

                            var order_cookie_data = readCookie('dm_order_details');
                            var json              = decodeURIComponent(order_cookie_data.replace(/\+/g, ' '));
                            var jsonObj           = JSON.parse(json);
                            // console.log(jsonObj);
                            chrome.storage.sync.set({'order_data': jsonObj});

                            setTimeout(() => {
                                show_progress_message('Redirecting.');
                                update_order_process_state('dm_order_cookie_set');                            
                            }, 2000);

                            setTimeout(() => {
                                window.location.href = jsonObj.url;
                            }, 3000);
                        }
                    }
                    if ( process_state == 'dm_order_cookie_set' ){
                        
                        show_progress_message('Getting product detail.',2);
                        update_order_process_state('dm_check_cart_status');

                        // set the same order cookie on aliexpress too
                        var date = new Date(); 
                        date.setTime(date.getTime() + (60 * 1000));                 
                        $.cookie('dm_order_process_cookie', 1, { expires: date });



                        setTimeout(function(){
                            show_progress_message('Redirecting to cart page.',2);
                        },2000);
                        setTimeout(function(){
                            window.location.href = 'https://shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm';
                        },3000)



                    }
                    if ( process_state == 'dm_check_cart_status' ){
                        
                        show_progress_message('Analyzing the cart.');

                        $.ajax({
                            url : 'https://shoppingcart.aliexpress.com/api/1.0/cart.do',
                            method :'GET',
                            beforeSend: function(xhr) {
                                xhr.setRequestHeader('content-encoding' , 'gzip');
                                xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                            },
                            success: function(res){
            
                                var p_quantity = res.captain.quantity;
                                
                                if (p_quantity > 0) {
                                    // cart is not empty

                                    setTimeout(function(){
                                        // show_progress_message('Getting Cart Item(s) Id(s)');
                                        var item_ids   = [];
                                        $.each(res.stores, function(indexStore,dataStore){
                                            $.each(dataStore.storeList, function(indexstoreList,datastoreList){
                                                $.each(datastoreList.products, function(indexdatastoreListproducts,datastoreListproducts){
                                                    item_ids.push(datastoreListproducts.itemId);									
                                                });
                                            });
                                        });
                                        
                                    },1000);

                                    setTimeout(function(){
                                        // show_progress_message('Deleting Cart Item(s)...');
                                        var item_ids   = [];
                                        $.each(res.stores, function(indexStore,dataStore){
                                            $.each(dataStore.storeList, function(indexstoreList,datastoreList){
                                                $.each(datastoreList.products, function(indexdatastoreListproducts,datastoreListproducts){
                                                    item_ids.push(datastoreListproducts.itemId);									
                                                });
                                            });
                                        });
                                        // empty the cart
                                        console.log('items to be deleted :', item_ids);
                                        var token      = parse_the_csrf_token();			
                                        var items_data = [];                                    
                                        $.each(item_ids, function(i,d){
                                            items_data.push({itemId : d, quantity:0});
                                        });                                
                                        var prm = '{"updates":'+JSON.stringify(items_data)+',"action":"DELETE_ITEMS","selected":"","_csrf_token_":"'+token+'"}';
                                        var url = "https://shoppingcart.aliexpress.com/api/1.0/cart.do";
                                        var xhttp = new XMLHttpRequest();  
                                            xhttp.open('POST', url, true);
                                            xhttp.setRequestHeader('Content-type', 'application/json');
                                            xhttp.onreadystatechange = function() {
                                                if(xhttp.readyState == 4 && xhttp.status == 200) {
                                                    console.log('Post request response : ',xhttp.responseText);
                                                    setTimeout(function(){
                                                        show_progress_message('Proceeding to add to cart...');
                                                        update_order_process_state('dm_add_to_cart');
                                                    },1000);
                                                    setTimeout(function(){
                                                        window.location.reload();
                                                    },2000);
                                                }
                                            }
                                            xhttp.send(prm);
                                    },2000);
                                }else{
                                    show_progress_message('Proceeding to add to cart...');
                                    update_order_process_state('dm_add_to_cart');

                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 2000);
                                }
                            },
                            error : function(err,e){
                                show_progress_message('Error: While checking cart items.');
                            }
                        });

                    }
                    if ( process_state == 'dm_add_to_cart' ) {
                        
                        show_progress_message('Adding product to cart...');
                        
                        var atc_url = 'https://shoppingcart.aliexpress.com/addToShopcart4Js.htm?productId=32858482533&quantity=1&country=IN&company=CAINIAO_STANDARD&promiseId=&cartfrom=main_detail&skuAttr=14%3A193%23BLACK%3B200000124%3A3434&skuId=65407548612&_csrf_token_=17yj472ga1chz&callback=__jp12';
                                                        
                        $.ajax({
                            url : atc_url ,
                            method :'GET',
                            beforeSend: function(xhr) {
                                xhr.setRequestHeader('content-encoding' , 'gzip');
                                xhr.setRequestHeader('content-type', 'application/json;charset=UTF-8');                    
                            },
                            success: function(res){
                                
                                show_progress_message('Product added to cart.');

                                update_order_process_state('dm_check_address_status');

                                setTimeout(() => {
                                    
                                    window.location.href = 'https://shoppingcart.aliexpress.com/order/confirm_order.htm?objectId=32800898453&from=aliexpress&countryCode=IN&shippingCompany=Other&provinceCode=&cityCode=&promiseId=&aeOrderFrom=main_detail&skuAttr=200000369%3A1394%3B200000783%3A29%23White+Silver+6mm&skuId=67059622038&skucustomAttr=&quantity=1';

                                }, 3000);
                                
                            },
                            error : function(err,e){
                                alert('Error: While adding to cart.');
                            }
                        });
    
                    }
                    if ( process_state == 'dm_check_address_status') {

                        show_progress_message('Analyzing shipping address.');

                        var url = "https://shoppingcart.aliexpress.com/api/1.0/orders.htm";

                        var required_data = get_required_data();     
                        
                        $.ajax({
                            url : url,
                            method : 'POST',
                            data : {
                                itemIds: '',
                                objectId: required_data['productId'],
                                aeOrderFrom: 'main_detail',
                                shippingCompany: required_data['shippingCompany'],
                                promiseId: '',
                                itemCondition: '',
                                skuAttr: required_data['skuAttr'],
                                quantity: '1',
                                pageQuantity: '',
                                selectedAddressId: '',
                                changeAddress: '',
                                provinceCode: '',
                                cityCode: '',
                                splitOrder: '',
                                splitOrderIds: '',
                                splitOrderNum: '',
                                splitOrderShopCartIds: '',
                                umidToken: required_data['umidToken'],
                            },
                            beforeSend: function(xhr){
                                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
                            },			                    	
                            success : function(res){
                                if (null != res.shipping.availableShippingMethods) {

                                    // show_progress_message('Shipping address available...');
                                    setTimeout(() => {
                                    
                                        var total_shipping_addresses   = res.shipping.availableShippingMethods.length;
                                        var deleted_shipping_addresses = 0;
                                        

                                        $.each(res.shipping.availableShippingMethods, function(a,b) {
                                            
                                            delete_an_aliexpress_address(b.shippingMethodId);
                                            deleted_shipping_addresses++;

                                            if (deleted_shipping_addresses == total_shipping_addresses) {
                                                // show_progress_message('Shipping addresses empty...');
                                                update_order_process_state('dm_create_shipping_address');
                                                setTimeout(() => {
                                                    window.location.reload();
                                                }, 1000);
                                            }
                                        });
                                        
                                    }, 2000);

                                } else {
                                    
                                    setTimeout(() => {
                                        show_progress_message('Creating shipping address.');
                                        create_new_aliexpress_address();
                                        setTimeout(function(params) {
                                            show_progress_message('Shipping address created.');

                                            update_order_process_state('dm_fill_order_note');
                                            
                                            setTimeout(function(params) {

                                                window.location.reload();

                                            },1000)

                                        },2000)
                                                            
                                    }, 2000);        		
                                }			
                            },
                            error : function(e,r){
                                show_progress_message('Error in Checking And Updating Shipping Address...');
                            }
                        });	

                    }
                    if ( process_state == 'dm_create_shipping_address') {
                        show_progress_message('Creating shipping address.');
                        create_new_aliexpress_address();
                        setTimeout(function() {
                            show_progress_message('Shipping address created.');
                            update_order_process_state('dm_fill_order_note');
                            setTimeout(function() {
                                window.location.reload();
                            },1000)
                        },3000)
                    }
                    if ( process_state == 'dm_fill_order_note') {
                        show_progress_message('Filling order note.');
                        fill_note();
                        setTimeout(() => {
                            show_progress_message('Verify the details and place the order.',0,2);

                            // remove process cookie.
                            var date = new Date(); 
                            date.setTime(date.getTime() - (60 * 2000));
                            $.cookie('dm_order_process_cookie', 1, { expires: date });
                            // remove process state data.
                            chrome.storage.sync.clear();return;                        
                        }, 1000);
                    }
                }
            });
            function update_order_process_state(c_state) {

                chrome.storage.sync.remove(c_state);

                var all_states = {dm_order_button_click   : 0,
                                dm_order_cookie_set     : 0,
                                dm_check_cart_status    : 0,
                                dm_delete_cart_items    : 0,
                                dm_add_to_cart          : 0,
                                dm_check_address_status : 0,
                                dm_delete_address       : 0,
                                dm_create_address       : 0,
                                dm_fill_order_note      : 0,
                                dm_order_process_done   : 0};

                $.each(all_states, function(state_name, val){
                    if (state_name == c_state) {                    
                        all_states[state_name] = 1 ;
                    } else {
                        all_states[state_name] = 0 ;
                    }
                });
                chrome.storage.sync.set({dm_order_process_state: all_states});

            }
            function readCookie(name) {
                var nameEQ = name + "=";
                var ca = document.cookie.split(';');
                for(var i=0;i < ca.length;i++) {
                    var c = ca[i];
                    while (c.charAt(0)==' ') c = c.substring(1,c.length);
                    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
                }
                return null;
            }
            function show_progress_message(message, auto_remove=0, fa_icon=1){

                var icon = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWMAAAFiCAYAAAAjnrlEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAF6tJREFUeNrs3U+MXVd9B/AzowgVt1gOpBZJQUyQgqp6gVtAlUoUG7WRQlGEkdIkK2JLyaJ/pNhythgCyzbyRF2g4ki2s4oBiaAIHClIsSO3XUCKWQwLLJWJqJxUIMc1IQELcN/v3jtz3zyPx+/NvHfPfe9+PtJokpA4M2cu3xx/7/kzlzrsp+9/aKH3aaH6070D//OeBIzb5d7Hjwb+/Hz1x+fvfOPU5a4OzFyHQnd39fHRKoB3+/8FtNKZ3sdy7+O16o87EdIzGcZV+O6rZre7+2a/wHRaroL5bHzuhfOyMG5vAK+E7z7hCzMvqo1v9z6e7wXzeWGcP4Bj1vt4FcA7PJ/Q2Vnz872Pp6d5xjx1YdwL4Ajd/VUImwED/c70Pk72QvmEMJ5cCEfwfrEKYoCNxAu/p3sfi9Py8q/1YdwL4b2priIARhWz5CfbXmG0NoyrmfDxdP36X4CZC+XWhbE6Apig1tYXrQrjXhB/KZWVhJURwCTF7PhQL5CfF8ZrQ3hv79PRZFcc0KwzvY8DbagusoZxtUwtKomDngkgk6grokte7GQYVxs2jpsNAy2aJX8uV5c8nymIYyb8Q0EMtMjeiKfqaIXZnhlXtUTMhq0ZBtosVlscmskwVksAU+ZMarC2aCSMq9US30qWrAHTJU6EO9DEyXATD+NeEO+vZsQA0yhmxp+adCBP9AWeIAZmQPyO/uVJv9ibWBhXu+kEMTArgfytaoI5EROpKXpfcITwfj8/YAYdmMR5yWOfGVdriAUxMKuOT2KGPNaZsY4Y6JA/H+dLvbHNjAUx0DEvV/sn2jMzrr6gH/rZAB0Ty97uHMfGkC3PjKvD4F/2MwE6aGXZ25Y3tG0pjKsvwM46oMuiGTiae2bsQHiAlPZXK8k2bdOdsRd2ANfZ9AqLTYVx9cIuemL1BEBtuQrkkV/obbamOC6IAa6zkDbZH48cxtWZE3pigPXt38yhQiPVFNYTAwxlOY1YV4w6Mz5qjAFuaiGVN9+Pf2Zs9QTAyIZeXTHUzLja3GFWDDCaoXNz2JoiFjNbPQEwmr3DHrd505qiOnvip8YUYFOW73zj1J3jmBl/0VgCbNrCMLPj+SFmxfuNJcCW3HRSO7/VXwCArc+O5zeYFe8wKwZoZna80cz4oLEDGOvseN9mwvgRYwcwVo+PFMZVt7Fg3ADGam+1MGLomfFnjRlAc7Pj+XVmxZHa+4wXwETsG3ZmLIgBJide5O0dJoy9uAOYrEc2DOOqonCLB8Bk7bvZzFhFATB5O6qbk24YxnuMEUAjHjEzBshv77phvN7bPQAmZnd1BtB1M2NhDJBpdtwfxvpigIZnx2bGAPntWRPGg0ssAGjE3sGZ8YIxAWjeyiluK2FsZgyQx5ow/qjxAMhib38Y7zAeAFl8qD+M9xoPgCwW+sMYgDyKZmLesjaArHavzIz1xQCZqSkAMosDgyKMFwwFQFa7hTFAC6gpAFrgFkMwmp3Hn0jz27d19vt/+8UfpCvHvutBAGGc16//48fpvV/+fGe//z/4qz8rxuDq0rKHAcZITTGimBVGGHX7dweHe787+EMPAwjjvH5x8Kvp91fe7u5vpz74x2nHEw94EEAY5/Xbn/28873p9sc+nbbd9wkPAwjjvC7/yzfT1aXXOj0Gtz399+oKEMb5/eLxr3b74dm+rQhkQBhnFSsKLj/1zU6Pwbb7Pp62P/a3HgYQxnmpK1LxMu9duxY8DCCM81JXqCtAGLdA1BVXjp3u9Bi8a9eHLHcDYZxf1BWx5K3Ldhx+oNihBwjjbH5/5VfFZpCuu23RcjcQxpnFNumu1xWxO6/LZ3eAMG4JdUVKf/TQHrvzQBjnpa4oxeqKmCUDwjibqCvi3N9OP1ix3G3RcjcQxpnF2uMun+wWYmWF3XkgjLMq6orH1RXxMs/uPBDGWb394vc7X1cEu/NAGGenrih35733y494GEAY5xN1xaUjJzs/DnEYvd15IIyzeuvU2c7fmxfKm7XtzgNhnFHX780rHjanu4Ewzi125cXuvK6Lw+hjhx4gjLOJS0zVFal4mWd3HgjjrNQVdueBMG4BdUUpVlY4jB6EcVZRV3T93rwQh9HbnQfCOCtbpUs7jx+23A2EcT5xb97lp9QV8SJPXQHCOKvojtUV5e48h9EjjMlKXVGKzSDqCoQx2agrqgfR7jyEMbld+drpzt+bF2J3nsPoEcZk4968WrzMszsPYUw2sU36yrHTHsjt24rT3UAYk02srlBXlIfRW+6GMCYbdUUtduc5jB5hTDZRV8Rh9KTiMCHL3RDGZHPpyLOdP9ktxIu8uF0ahDFZFHWFzSCFOIje7jyEMdm8/eL3ex8/MBDJ7jyEMZnF7FhdsbLc7bAHAmFMHuqKWqyssDsPYUw2UVe4N68UL/McRo8wJhv35tUcJoQwJhv35tVid17cLg3CmCzi3jx1RSkOo7c7D2FMNuqKmt15CGOyUVfUYnee/hhhTDZRV7g3rxSH0ccOPRDGZGHtcS1e5jmMnpn43Z4hmD5xb97rZ19N83/6AYPRs/2r/5Te9Zvfdfb7j/cI5W7NX3kYhDGNevjudHXhtpR+/WtjceFi+s0/PpM+8P1/LbZNd/d3CJ93FvaUU1NMm9tvTXOP/o1xqFz7yjdsG09OtxPGNG7uCw/2/p/3bgMRnvleSj+5WPyhU+6cbieMac7Dd6f0Fx82DuHCxXTtmZfW/KVLR052eh220+2EMU1QT6wR9cQg67CdbieMmbi5Q/erJ1acOrdaTwyybTwVN2s73U4YMwl7dqV0zy7jEF5/M12LrngDXd82HnWF3YnCmHF7z7vT3Bf+zjhUrn3l6yn98p0N/x51RXm6XcyQEcaMSRHE6olS1BP/9d9D/a3qipR2HH7A6XbCmLFQT9SGqCcGXTrybOeHzel2wpitUk+sMUw9MSi2jV9+qtt1hdPthDFbVCxjU0+UvvPq0PXEoOiOu37KXZxuZ3eeMGYzYmPHQ3cbh/DWO+na4gtb+iWcclfuznO6nTBmFEU98aBxqBSbO0asJwapK6rlbovqCmHM0Ip64vZbDUR4ZSmls0tj+aWiroglb11md54wZljqiVrUE+tsed4KR0yWR23anSeMudmsWD2xahz1xKBYd3zl2OnOj63T3YQxGwXxo/eqJ1bEyokx1ROD1BV25wljbuwjd6TkRLZSUU98fWK/fHEQvboibX/s03bnCWOumxXb3LGq2GX3+psT/XeoK0o7jz+hrhDGrAZx1BN33WEgQtQTz51r5F+lrnC6mzCmpp6oTbieGBR1hbMryt15cX8ewrjbs+KD9xuEShP1xCD35pXe++VH7M4Txh3mPrvahYuN1RODYqt0lw+iL0KguDvvCc+hMO4g99mtnRWPeXPHKIrVFc6usNxNGHdTsbnDiWylqCducJ9dU9QVpTiM3u48Ydwd6onahYvp2jMvteJLUVeUdh4/bLmbMO4A9cQaOeuJQVFXdP3evBAv8tQVwnjmqSf6tKCeGOTevFLsznMYvTCeXXGfnXqiFPfZnTrXyi8ttkqrKxwmJIxnlfvs1tjMfXZNiV156oqV5W6HPazCeLYUQayeKMWMeJP32TVFXVFyGL0wni1RT9yzyziEqCeiK54CTnYrxcs8y92E8fRTT6zR5npiUFFXPKWucJiQMJ4JxdkT6onSd15tfT0xKLrjq0uvdf5HZ3eeMJ5usXLiMx8zDiFOZFt8YSq/dFulS7E7z2H0wnj6FPWE++xWTOI+u6ZcXVpWV1RuW7TcTRhPmWKXnfvsSq8sTew+u6aoK0qxOy9ul0YYT4eoJx662ziE4sD4b8zEt3LpyEk/z544iN7uPGHcfuqJNaa5nhjk3rxarK5wGL0wbrW5mBGrJ0ozUE8Mcm9eFRqx3G3Rcjdh3Fbus6tFPXH0hZn7toqD6G0GKdidJ4zbOyu2uWNVjvvsmqKuqMXLPLvzhHG7gvjRe1O66w4DEWJjx3PnZvpbVFfU7M4Txu2hnqgVqye+PvPfZtQVl4486+edyt15cbs0wjj/rFg9sWqW64lB7s2rxWH0ducJ47ziPjv1RKkD9cQg9+bVdh5/wu48YZyJ++zWzooXX+jc91ysrnB2RRkkTncTxrm4z65PC++za4q6orbtvo8XO/QQxs2JesJ9dqULF9O1Z17q9BCoK2rxMs/uPGHcDPXEGrNy9sRWlKsrnF1RBIrdecK4KeqJPh2uJwa9deqse/MqsbLCYfSju8UQjOaDf/2XxX/9u+rKmfPp0j9Xa4mn7OaOSfvf0/+Z0p9YUVD48PuMgZnxZHX97fn2vbvTtp3vE8SD4oCohz9pHCpd2PwjjDPz9rzcAmtN6Vrqqz4d2vwjjFswO+7y23NrSgdYXVOzukYYN8li/3JNqSMUk9U1A6yuEcaNi7qi62/P4415149QVE/0sbpGGOcSB42rKzpcV6gnauoJYZxTnGkbZ9t2WRyh2Mk1pXHfoXpi1Sze7CKMp8yVY99VVxx+oHNHKBZHp6onSqfOWeoojNuh63VFiC2wnVnutmdXSvfs8uCH198sz7FGGLeBuiIVh8PEnWgzL+oJFwqsKjZ3/PIdAyGM2yPqiqtLr3V6DOL4xG33fWKmv0f1RB/1hDBuKweNl7vzZvYIRfVETT0hjNvs6tJyuvxUt+uKmT1CMeqJg/d7yCvqCWHcetEdd72uiJUVs7Y7r1jGFocBkdIrS+oJYTwd1BWpeJk3M7vzYmPHQ3d7sMNb79jyLIynh7qiNBO784rVEw96qCtFEKsnhPE0ufK108WSty6L3XlxJ9o0U0/0iXri7JJxEMbTpTjZ7aC6Yvtjn57e3XnqiZp6QhhPs9gmfeXY6c6Pw7Tuzps7ZPXEiuLsCfWEMJ5msbqi63VFrDuetv547tF7U7rrDg9wiJUT33nVOAjj6aauKMVh9LFDbyp8pBfCTmQrFfWE++yE8YyIuiKucu+6eJk3DbvznD1Ru+Y+O2E8ay4debbzJ7tNw+489USfqCeeO2cchPFscW9eKVZWtPYw+ljCpp4oqSeE8SyLe/PefvEHnR+HOIy+jbvzbO7o89y/qyeE8WyL2XHX64oQqytatdzNfXY199kJ4y5QV5RadXfe7be6z66PzR3CuDPUFaXYndeGw+iLesKB8aVYPfGTi8ZBGHfHpSMn1RWpBXWFeqKmnhDGXeTevOoBjOVuuXbnxYls6olV6glh3Flxb15sCOm62J2X4zB699n1ifvs1BPCuMtiq7S6IhUv8xrdnec+u5r77IQx6orVB3H7trTz+BPN/MuKA+NteV7hPjthTEVdUWpquZt6ok/UE+6zE8bU4uwKyt15Ez2MXj1RU08IY67n3rzaxA6jV0+soZ4QxtxAdMdXl17r/DjEi7y4XXrcimVs6olS3GennhDG3Jit0qU4iH6su/PcZ1dzn50w5ubUFbWx7c4r6gknsq0oglg9IYy5OffmVQ9nsdzt8JZ/naKeiLOKKeuJs0vGQRgzLPfmlWJlxZZ256knauoJYczoYt3xlWOnDURKxcu8zR5Gr56oqSeEMZukrqht5jCh4j479UQpVk6oJ4Qxm1McRK+uKMTuvLhdemgfucN9divcZyeM2Tp1RS0Oox92d57NHbVil5377IQxWxd1hZPdSsPszivqibvuMFgh6onnzhkHYcw4uDevFrvzNuyP1RM19YQwZvzcm1eLw+hvtDtv7uD9BqiinhDGTEjMjtUVpZgdX3cYvfvsahcuqieEMZOiruh7cOPuvMW+uuL2W91n1z8rtrlDGDNZ6oparKxYOYy+2NzhRLZS1BPus5s6txiC6XPpyMkiiGJ22HVxGP1b6Xfpd+qJ0oWL6dozLxkHYUwTfnv5rfSzH//E7rKV35L/z89T+od/MxDBCzthTHPm4uAbQVyyjpYZoTOeNtbR1qyjRRiTbVZsm+8q62gRxuQJYtt8a+oJhDFZqCdq6gmEMdlmxeqJVeoJhDF5xDZf9UTJNl+EMVnY5rt2VmybL8KYHGzz7WObL8KYLJxCVrPNF2FMFuqJNdQTCGOyUE/0UU8gjMlizy71xIrX31RPIIzJ4D3vtqa4j80dCGOyKIJYPVE6da7c9gzCmEZFPXHPLuMQinrie8YBYUzD1BNrFPXEL98xEAhjmlVcMa+eKKknEMZkESsnPvMx4xDiRDb1BMKYxhX1xIPGoVJs7lBPIIxpWrHLzn12pVeWUjq7ZBwQxjQs6om4XJTqwHhbnhHGNE09sYZ6AmFMFnMxI1ZPlNQTIIyzcJ9dLeqJoy8YB4SxIcgwK7a5Y5X77EAY5wniR+91n92K2NjhPjsQxo1TT9SK1RNOZANhnGNWrJ5YpZ4AYZwniNUTNfUECOMsYgnbw580Diuz4kWrJ0AY55gVu8+u5j47EMZZPHy3++xWXLjoPjsQxhncfmt5EBAFZ0+AMM5CPdFHPQHCOIs4LF49USrus1NPgDBuWpzIduh+41CxuQOEcRbF5g71RMl9diCMs9izK6V7dhmHUNQT7rMDYdy04sB4W55XFPWEA+NBGDdNPdFHPQHCOItYOaGeKKknQBhn4T67NYqzJ9QTIIybVuyyc59dyX12IIyziHoiLhelOjDelmcQxk1TT6xRBLF6AoRx09QTfdQTIIyziPvs1BMl9QQI42yzYps7VhXL2NQTIIwbD2L32dXcZwfCOIuoJxwYXyrqCSeygTDOMStWT6wq6onX3zQQMAa3GIIRA+iom41XOXsChLEAAmZJ1BSXDQNA/jA+bxgAsrrsBR5AZne+ceq8MAZoATUFQF7Fe7v53vTYCzyAfM6vzIzDsvEAyDgzFsYAWf2oP4z1xgB5LPeH8WvGAyB/GJsZA2Rw5xunzqyG8cqfANCo1Ynw/Hp/EQBhDNAVZ9cL47PGBSD/zPiMcQFozHIcEHRdGPf+4nJSVQA0Zc0EeH6j/xGAiTm7URh/2/gANOL5G4Zxtd7YKW4AEw7iwRMz52+W1gCM3XUtxHphfNI4AUx2ZnzTMK6qimVjBTCZIF7vUo8b3YFndgwwGevm643C+ITxAhi72Ojx/NBhXG0AEcgADcyKN5oZb/gPATCy6IkXRw7j6kXeGeMHMBbrvrgbZmYcnjR+AGOxYZ5uGMZmxwBjcaJ6F7e5MDY7Bpj8rHioMDY7BthaEN9sVjzszNjsGGBzNlxBMXIYV7PjE8YVYORZ8VAnYc6P8IseSo7XBBjW+V4QLw77Nw8dxlW6qysAhp/ADm2UmXGqUv6MMQbY0GJV704mjCsHkroC4EaW0yZahJHDuFqioa4AWN/nhn1pt9WZ8Upd4XomgLVi9cT5zfyD81v4lx5IbgQBWHGmF8Rf2uw/vOkwrqbhnzP+AGnLebiVmXGqpuMH/ByAjgfxpzbTE48tjKtAPpGG3O4HMIMObbYnHmsYV4Eci5tP+JkAHfNkNSHdsvkxflERyOf9bICOOLGVF3aD5sb5lf30/Q/t6H16ufex288JmPEgHuv7srlxf4UCGRDELQhjgQwI4paEsUAGBPFo5if1C1dr7j6VnPIGCOJ8M+OBWfLx3qf9fp7AFDo0yiHxrZsZD8yS478oTnoDpkn87v5AE0Hc2My4b4a8r/cpZsk7/JyBFltO5VGYje2dmGv6O+wF8kLv07eSF3tAOz1fzYgbvURjLtd32wvlo71PB/3cgRY51FQt0ZowrgJ5bzVLVlsAOZ2vZsPZjnSYyz0C1XrkmCXv9zwAGTw5zjMmpjaMB2bJ8XJvwbMBNOBMNRtebsMXM9e20emFcvwX6vGkugAmI8I3uuFW3eM518aRqqqLLyYv+IDxidURT7ehkpiaMO4L5YUqlPd7joCthHDvY7Hp5WozE8YDofx4FcrqC2AYy72Pk20P4akK475Q3lEFcgTzgmcNWMeZCOFxXYckjG8ezHt7nx7pfewzWwaz4FTunHu6LasjOhPGA8EcgfxZwQydC+CYBX+7bSsjOhvG68yYI5jjs/MvYLZE+J6NWXDO3XLCePRg3tEXynuqz2bOMD0z3wjcH0UI98L3zCx/s3Nd++lWAR2hvFB9fCjVLwOFNTTnchW2qfr8f9Xny7MevOv5fwEGAMjmjanXdVzIAAAAAElFTkSuQmCC';
                
                if ($("#dm-progress-message").length > 0) {
                    $("#dm-progress-message").remove();
                }

                if (fa_icon==1) {
                    fa_icon = '<i class="fa fa-spinner fa-spin" style="font-size: 20px;position: relative;top: -20px;right: -10px;color: #df1657;"></i>';
                }else if (fa_icon==2){
                    fa_icon = '<i class="fa fa-check" style="font-size: 12px;position: relative;top: -25px;right: -15px;color: rgba(223, 22, 87, 0.67);border: 2px solid;border-radius: 17px;padding: 4px 4px;"></i>';
                }else if (fa_icon==3){
                    fa_icon = '<i class="fa fa-info" style="font-size: 12px;position: relative;top: -25px;right: -15px;color: rgba(223, 22, 87, 0.67);border: 2px solid;border-radius: 17px;padding: 4px 8px;"></i>';
                }
                
                var id = generateToken(10);

                var block = '';


                block += '<div id="dm-progress-message" class="'+id+'_message" style="cursor:pointer;background: white;position: fixed;right: 50px;top: 71px;z-index: 10000;width: 100%;max-width: 270px;padding: 30px 20px;border-left: 4px solid #df1657;box-shadow: 0 4px 2px rgba(176, 176, 181, 0.16);border-top: 1px solid #e6e1e1;border-right: 1px solid #e6e1e1;border-bottom: 1px solid #e6e1e1;">';
                block += '<div style="position: relative">';
                block += '<img style="width: 29px;position: absolute;top: 50%;left: -14px;transform: translateY(-50%);" src="'+icon+'"/>';

                block += '<div style="position: absolute;top:0;right:0">'+fa_icon+'</div>';
                block += '<div style="padding:0 0 0 22px">'+message+'</div>';
                block += '<div style="padding: 0 0 0 22px;font-size: 11px;color: #d8dae0;bottom: -27px;position: absolute;right: -15px;">Dropmarket Chrome Extension.</div>';
                // block += '<span style="font-size: 26px;position: absolute;top: 50%;right: -14px;transform: translateY(-50%) rotate(45deg);color: #575757;font-weight: 900;"><span>+</span></span>';
                block += '</div>';
                block += '</div>';
                
                $('body #dm-progress-message').remove();
                $('body').append( block );
                
                if (auto_remove > 0) {
                    setTimeout(() => {
                        $('.'+id+'_message').fadeOut(500, function() { $(this).remove(); });
                    }, auto_remove * 1000);
                    
                }
            }
        /**------------ Product order process end (Aliexpress) ------------*/

    });
    
}


function generateToken(n) {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var token = '';
    for(var i = 0; i < n; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}
function parse_the_csrf_token() {
	var crs =  null;				
	var e = !0,
	t = !1,
	r = void 0;
	for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
	    var i = n.value, a = i.innerText.match(/\._csrf_token_\s=\s'(\w+)';/);
	    
	    if (null !== a) {
	    	crs =  a[1]
	    }
	}
	return crs;	
}
function get_required_data() {

	var skuAttr = null;
	var umidToken = null;
	var productId = null;
	
    for (var n, o = this.document.body.querySelectorAll("script")[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
    	
    	if (n.value.innerText.indexOf('"skuAttr":') != -1) {
    		
    		var data  = n.value.innerText.match(/skuAttr":(.*),/);
    		var data2 = n.value.innerText.match(/umidToken":(.*),/);
    		var data3 = n.value.innerText.match(/shippingCompany":(.*),/);   		
    		var data4 = n.value.innerText.match(/productId":(.*),/);   		
    		
    		skuAttr         = data[1];
    		umidToken       = data2[1];
    		shippingCompany = data3[1];    		
    		productId       = data4[1];    		
    		
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = skuAttr.replace('"','');
    		skuAttr = $.trim(skuAttr);
    		
    		umidToken = umidToken.replace('"','');
    		umidToken = umidToken.replace('"','');
    		umidToken = $.trim(umidToken);
    		
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = shippingCompany.replace('"','');
    		shippingCompany = $.trim(shippingCompany);
    		
    		productId = productId.replace('"','');
    		productId = productId.replace('"','');
    		productId = $.trim(productId);
    	}
    }
    return {skuAttr : skuAttr, umidToken : umidToken, shippingCompany : shippingCompany, productId : productId};
}
function delete_an_aliexpress_address(address_id) {
	
	var crs = parse_the_csrf_token();
	
    var deleteAddress = 'https://ilogisticsaddress.aliexpress.com/ajaxDeleteLogisticsAddress.htm?addressId='+address_id+'&_csrf_token_='+crs;

    $.ajax({
    		url : deleteAddress,
    		method : 'GET',
    		beforeSend: function(xhr){
			 	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			 	xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")
			 },
    		success : function(res){					                    			
    			console.log('Address deleted.');
    		},
    		error : function(e,r){
    			console.log(e)					                    				
    			console.log(r)					                    				
    		}
    });
    

}
function create_new_aliexpress_address(CUSTOMER_DATA_OBJECT='') {
    var ALIEXPRESS_SHIPPING_ADDRESS_URL = 'https://ilogisticsaddress.aliexpress.com/ajaxSaveOrUpdateBuyerAddress.htm';
    var crs = parse_the_csrf_token();
    
    CUSTOMER_DATA =	{   _csrf_token_: crs,
                        phoneCountry: '+91',
                        contactPerson: 'test',
                        mobileNo: '9876543210',
                        address: 'test address 1',
                        address2: 'test address 2',
                        zip: '160055',
                        country: 'IN',
                        province: 'Punjab',
                        city: 'mohali',
                        features: '{"ruPassport":"taxNumber","locale":"en_US"}',
                        shipcompany: 'Other',
                        useLocalAddress: true
    };
    $.ajax({ 
        url : ALIEXPRESS_SHIPPING_ADDRESS_URL,
        method : 'POST',
        data : CUSTOMER_DATA,
        beforeSend: function(xhr){
            xhr.setRequestHeader('Accept','application/json, text/plain, */*')
            xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')

        },
        success : function(res){
            console.log('Address successfully created.');
        },
        error : function(a,b){
            console.log(a)
            console.log(b)
        }
    });    
}
function fill_note() {
    var seller_message = 'I\'m dropshipping. Please DO NOT put any invoices, QR codes, promotions or your brand name logo in the shipments. Please ship as soon as possible for repeat business. Thank you!';
    document.querySelectorAll(".seller-message .seller-message-input").forEach(function(e) {
        e.click(), e.className = e.className.replace("folded", "unfolded")
    }),document.querySelectorAll('.seller-message textarea[ae_button_type="message"]').forEach(function(t) {
        Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set.call(t, seller_message), t.dispatchEvent(new Event("change", {
            bubbles: !0
        }))
    });
}


$(function() {
    show_progress_message1('Waiting for page load.', 0, 1);

});

function show_progress_message1(message, auto_remove=0, fa_icon=1){

    var icon = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWMAAAFiCAYAAAAjnrlEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAF6tJREFUeNrs3U+MXVd9B/AzowgVt1gOpBZJQUyQgqp6gVtAlUoUG7WRQlGEkdIkK2JLyaJ/pNhythgCyzbyRF2g4ki2s4oBiaAIHClIsSO3XUCKWQwLLJWJqJxUIMc1IQELcN/v3jtz3zyPx+/NvHfPfe9+PtJokpA4M2cu3xx/7/kzlzrsp+9/aKH3aaH6070D//OeBIzb5d7Hjwb+/Hz1x+fvfOPU5a4OzFyHQnd39fHRKoB3+/8FtNKZ3sdy7+O16o87EdIzGcZV+O6rZre7+2a/wHRaroL5bHzuhfOyMG5vAK+E7z7hCzMvqo1v9z6e7wXzeWGcP4Bj1vt4FcA7PJ/Q2Vnz872Pp6d5xjx1YdwL4Ajd/VUImwED/c70Pk72QvmEMJ5cCEfwfrEKYoCNxAu/p3sfi9Py8q/1YdwL4b2priIARhWz5CfbXmG0NoyrmfDxdP36X4CZC+XWhbE6Apig1tYXrQrjXhB/KZWVhJURwCTF7PhQL5CfF8ZrQ3hv79PRZFcc0KwzvY8DbagusoZxtUwtKomDngkgk6grokte7GQYVxs2jpsNAy2aJX8uV5c8nymIYyb8Q0EMtMjeiKfqaIXZnhlXtUTMhq0ZBtosVlscmskwVksAU+ZMarC2aCSMq9US30qWrAHTJU6EO9DEyXATD+NeEO+vZsQA0yhmxp+adCBP9AWeIAZmQPyO/uVJv9ibWBhXu+kEMTArgfytaoI5EROpKXpfcITwfj8/YAYdmMR5yWOfGVdriAUxMKuOT2KGPNaZsY4Y6JA/H+dLvbHNjAUx0DEvV/sn2jMzrr6gH/rZAB0Ty97uHMfGkC3PjKvD4F/2MwE6aGXZ25Y3tG0pjKsvwM46oMuiGTiae2bsQHiAlPZXK8k2bdOdsRd2ANfZ9AqLTYVx9cIuemL1BEBtuQrkkV/obbamOC6IAa6zkDbZH48cxtWZE3pigPXt38yhQiPVFNYTAwxlOY1YV4w6Mz5qjAFuaiGVN9+Pf2Zs9QTAyIZeXTHUzLja3GFWDDCaoXNz2JoiFjNbPQEwmr3DHrd505qiOnvip8YUYFOW73zj1J3jmBl/0VgCbNrCMLPj+SFmxfuNJcCW3HRSO7/VXwCArc+O5zeYFe8wKwZoZna80cz4oLEDGOvseN9mwvgRYwcwVo+PFMZVt7Fg3ADGam+1MGLomfFnjRlAc7Pj+XVmxZHa+4wXwETsG3ZmLIgBJide5O0dJoy9uAOYrEc2DOOqonCLB8Bk7bvZzFhFATB5O6qbk24YxnuMEUAjHjEzBshv77phvN7bPQAmZnd1BtB1M2NhDJBpdtwfxvpigIZnx2bGAPntWRPGg0ssAGjE3sGZ8YIxAWjeyiluK2FsZgyQx5ow/qjxAMhib38Y7zAeAFl8qD+M9xoPgCwW+sMYgDyKZmLesjaArHavzIz1xQCZqSkAMosDgyKMFwwFQFa7hTFAC6gpAFrgFkMwmp3Hn0jz27d19vt/+8UfpCvHvutBAGGc16//48fpvV/+fGe//z/4qz8rxuDq0rKHAcZITTGimBVGGHX7dweHe787+EMPAwjjvH5x8Kvp91fe7u5vpz74x2nHEw94EEAY5/Xbn/28873p9sc+nbbd9wkPAwjjvC7/yzfT1aXXOj0Gtz399+oKEMb5/eLxr3b74dm+rQhkQBhnFSsKLj/1zU6Pwbb7Pp62P/a3HgYQxnmpK1LxMu9duxY8DCCM81JXqCtAGLdA1BVXjp3u9Bi8a9eHLHcDYZxf1BWx5K3Ldhx+oNihBwjjbH5/5VfFZpCuu23RcjcQxpnFNumu1xWxO6/LZ3eAMG4JdUVKf/TQHrvzQBjnpa4oxeqKmCUDwjibqCvi3N9OP1ix3G3RcjcQxpnF2uMun+wWYmWF3XkgjLMq6orH1RXxMs/uPBDGWb394vc7X1cEu/NAGGenrih35733y494GEAY5xN1xaUjJzs/DnEYvd15IIyzeuvU2c7fmxfKm7XtzgNhnFHX780rHjanu4Ewzi125cXuvK6Lw+hjhx4gjLOJS0zVFal4mWd3HgjjrNQVdueBMG4BdUUpVlY4jB6EcVZRV3T93rwQh9HbnQfCOCtbpUs7jx+23A2EcT5xb97lp9QV8SJPXQHCOKvojtUV5e48h9EjjMlKXVGKzSDqCoQx2agrqgfR7jyEMbld+drpzt+bF2J3nsPoEcZk4968WrzMszsPYUw2sU36yrHTHsjt24rT3UAYk02srlBXlIfRW+6GMCYbdUUtduc5jB5hTDZRV8Rh9KTiMCHL3RDGZHPpyLOdP9ktxIu8uF0ahDFZFHWFzSCFOIje7jyEMdm8/eL3ex8/MBDJ7jyEMZnF7FhdsbLc7bAHAmFMHuqKWqyssDsPYUw2UVe4N68UL/McRo8wJhv35tUcJoQwJhv35tVid17cLg3CmCzi3jx1RSkOo7c7D2FMNuqKmt15CGOyUVfUYnee/hhhTDZRV7g3rxSH0ccOPRDGZGHtcS1e5jmMnpn43Z4hmD5xb97rZ19N83/6AYPRs/2r/5Te9Zvfdfb7j/cI5W7NX3kYhDGNevjudHXhtpR+/WtjceFi+s0/PpM+8P1/LbZNd/d3CJ93FvaUU1NMm9tvTXOP/o1xqFz7yjdsG09OtxPGNG7uCw/2/p/3bgMRnvleSj+5WPyhU+6cbieMac7Dd6f0Fx82DuHCxXTtmZfW/KVLR052eh220+2EMU1QT6wR9cQg67CdbieMmbi5Q/erJ1acOrdaTwyybTwVN2s73U4YMwl7dqV0zy7jEF5/M12LrngDXd82HnWF3YnCmHF7z7vT3Bf+zjhUrn3l6yn98p0N/x51RXm6XcyQEcaMSRHE6olS1BP/9d9D/a3qipR2HH7A6XbCmLFQT9SGqCcGXTrybOeHzel2wpitUk+sMUw9MSi2jV9+qtt1hdPthDFbVCxjU0+UvvPq0PXEoOiOu37KXZxuZ3eeMGYzYmPHQ3cbh/DWO+na4gtb+iWcclfuznO6nTBmFEU98aBxqBSbO0asJwapK6rlbovqCmHM0Ip64vZbDUR4ZSmls0tj+aWiroglb11md54wZljqiVrUE+tsed4KR0yWR23anSeMudmsWD2xahz1xKBYd3zl2OnOj63T3YQxGwXxo/eqJ1bEyokx1ROD1BV25wljbuwjd6TkRLZSUU98fWK/fHEQvboibX/s03bnCWOumxXb3LGq2GX3+psT/XeoK0o7jz+hrhDGrAZx1BN33WEgQtQTz51r5F+lrnC6mzCmpp6oTbieGBR1hbMryt15cX8ewrjbs+KD9xuEShP1xCD35pXe++VH7M4Txh3mPrvahYuN1RODYqt0lw+iL0KguDvvCc+hMO4g99mtnRWPeXPHKIrVFc6usNxNGHdTsbnDiWylqCducJ9dU9QVpTiM3u48Ydwd6onahYvp2jMvteJLUVeUdh4/bLmbMO4A9cQaOeuJQVFXdP3evBAv8tQVwnjmqSf6tKCeGOTevFLsznMYvTCeXXGfnXqiFPfZnTrXyi8ttkqrKxwmJIxnlfvs1tjMfXZNiV156oqV5W6HPazCeLYUQayeKMWMeJP32TVFXVFyGL0wni1RT9yzyziEqCeiK54CTnYrxcs8y92E8fRTT6zR5npiUFFXPKWucJiQMJ4JxdkT6onSd15tfT0xKLrjq0uvdf5HZ3eeMJ5usXLiMx8zDiFOZFt8YSq/dFulS7E7z2H0wnj6FPWE++xWTOI+u6ZcXVpWV1RuW7TcTRhPmWKXnfvsSq8sTew+u6aoK0qxOy9ul0YYT4eoJx662ziE4sD4b8zEt3LpyEk/z544iN7uPGHcfuqJNaa5nhjk3rxarK5wGL0wbrW5mBGrJ0ozUE8Mcm9eFRqx3G3Rcjdh3Fbus6tFPXH0hZn7toqD6G0GKdidJ4zbOyu2uWNVjvvsmqKuqMXLPLvzhHG7gvjRe1O66w4DEWJjx3PnZvpbVFfU7M4Txu2hnqgVqye+PvPfZtQVl4486+edyt15cbs0wjj/rFg9sWqW64lB7s2rxWH0ducJ47ziPjv1RKkD9cQg9+bVdh5/wu48YZyJ++zWzooXX+jc91ysrnB2RRkkTncTxrm4z65PC++za4q6orbtvo8XO/QQxs2JesJ9dqULF9O1Z17q9BCoK2rxMs/uPGHcDPXEGrNy9sRWlKsrnF1RBIrdecK4KeqJPh2uJwa9deqse/MqsbLCYfSju8UQjOaDf/2XxX/9u+rKmfPp0j9Xa4mn7OaOSfvf0/+Z0p9YUVD48PuMgZnxZHX97fn2vbvTtp3vE8SD4oCohz9pHCpd2PwjjDPz9rzcAmtN6Vrqqz4d2vwjjFswO+7y23NrSgdYXVOzukYYN8li/3JNqSMUk9U1A6yuEcaNi7qi62/P4415149QVE/0sbpGGOcSB42rKzpcV6gnauoJYZxTnGkbZ9t2WRyh2Mk1pXHfoXpi1Sze7CKMp8yVY99VVxx+oHNHKBZHp6onSqfOWeoojNuh63VFiC2wnVnutmdXSvfs8uCH198sz7FGGLeBuiIVh8PEnWgzL+oJFwqsKjZ3/PIdAyGM2yPqiqtLr3V6DOL4xG33fWKmv0f1RB/1hDBuKweNl7vzZvYIRfVETT0hjNvs6tJyuvxUt+uKmT1CMeqJg/d7yCvqCWHcetEdd72uiJUVs7Y7r1jGFocBkdIrS+oJYTwd1BWpeJk3M7vzYmPHQ3d7sMNb79jyLIynh7qiNBO784rVEw96qCtFEKsnhPE0ufK108WSty6L3XlxJ9o0U0/0iXri7JJxEMbTpTjZ7aC6Yvtjn57e3XnqiZp6QhhPs9gmfeXY6c6Pw7Tuzps7ZPXEiuLsCfWEMJ5msbqi63VFrDuetv547tF7U7rrDg9wiJUT33nVOAjj6aauKMVh9LFDbyp8pBfCTmQrFfWE++yE8YyIuiKucu+6eJk3DbvznD1Ru+Y+O2E8ay4debbzJ7tNw+489USfqCeeO2cchPFscW9eKVZWtPYw+ljCpp4oqSeE8SyLe/PefvEHnR+HOIy+jbvzbO7o89y/qyeE8WyL2XHX64oQqytatdzNfXY199kJ4y5QV5RadXfe7be6z66PzR3CuDPUFaXYndeGw+iLesKB8aVYPfGTi8ZBGHfHpSMn1RWpBXWFeqKmnhDGXeTevOoBjOVuuXbnxYls6olV6glh3Flxb15sCOm62J2X4zB699n1ifvs1BPCuMtiq7S6IhUv8xrdnec+u5r77IQx6orVB3H7trTz+BPN/MuKA+NteV7hPjthTEVdUWpquZt6ok/UE+6zE8bU4uwKyt15Ez2MXj1RU08IY67n3rzaxA6jV0+soZ4QxtxAdMdXl17r/DjEi7y4XXrcimVs6olS3GennhDG3Jit0qU4iH6su/PcZ1dzn50w5ubUFbWx7c4r6gknsq0oglg9IYy5OffmVQ9nsdzt8JZ/naKeiLOKKeuJs0vGQRgzLPfmlWJlxZZ256knauoJYczoYt3xlWOnDURKxcu8zR5Gr56oqSeEMZukrqht5jCh4j479UQpVk6oJ4Qxm1McRK+uKMTuvLhdemgfucN9divcZyeM2Tp1RS0Oox92d57NHbVil5377IQxWxd1hZPdSsPszivqibvuMFgh6onnzhkHYcw4uDevFrvzNuyP1RM19YQwZvzcm1eLw+hvtDtv7uD9BqiinhDGTEjMjtUVpZgdX3cYvfvsahcuqieEMZOiruh7cOPuvMW+uuL2W91n1z8rtrlDGDNZ6oparKxYOYy+2NzhRLZS1BPus5s6txiC6XPpyMkiiGJ22HVxGP1b6Xfpd+qJ0oWL6dozLxkHYUwTfnv5rfSzH//E7rKV35L/z89T+od/MxDBCzthTHPm4uAbQVyyjpYZoTOeNtbR1qyjRRiTbVZsm+8q62gRxuQJYtt8a+oJhDFZqCdq6gmEMdlmxeqJVeoJhDF5xDZf9UTJNl+EMVnY5rt2VmybL8KYHGzz7WObL8KYLJxCVrPNF2FMFuqJNdQTCGOyUE/0UU8gjMlizy71xIrX31RPIIzJ4D3vtqa4j80dCGOyKIJYPVE6da7c9gzCmEZFPXHPLuMQinrie8YBYUzD1BNrFPXEL98xEAhjmlVcMa+eKKknEMZkESsnPvMx4xDiRDb1BMKYxhX1xIPGoVJs7lBPIIxpWrHLzn12pVeWUjq7ZBwQxjQs6om4XJTqwHhbnhHGNE09sYZ6AmFMFnMxI1ZPlNQTIIyzcJ9dLeqJoy8YB4SxIcgwK7a5Y5X77EAY5wniR+91n92K2NjhPjsQxo1TT9SK1RNOZANhnGNWrJ5YpZ4AYZwniNUTNfUECOMsYgnbw580Diuz4kWrJ0AY55gVu8+u5j47EMZZPHy3++xWXLjoPjsQxhncfmt5EBAFZ0+AMM5CPdFHPQHCOIs4LF49USrus1NPgDBuWpzIduh+41CxuQOEcRbF5g71RMl9diCMs9izK6V7dhmHUNQT7rMDYdy04sB4W55XFPWEA+NBGDdNPdFHPQHCOItYOaGeKKknQBhn4T67NYqzJ9QTIIybVuyyc59dyX12IIyziHoiLhelOjDelmcQxk1TT6xRBLF6AoRx09QTfdQTIIyziPvs1BMl9QQI42yzYps7VhXL2NQTIIwbD2L32dXcZwfCOIuoJxwYXyrqCSeygTDOMStWT6wq6onX3zQQMAa3GIIRA+iom41XOXsChLEAAmZJ1BSXDQNA/jA+bxgAsrrsBR5AZne+ceq8MAZoATUFQF7Fe7v53vTYCzyAfM6vzIzDsvEAyDgzFsYAWf2oP4z1xgB5LPeH8WvGAyB/GJsZA2Rw5xunzqyG8cqfANCo1Ynw/Hp/EQBhDNAVZ9cL47PGBSD/zPiMcQFozHIcEHRdGPf+4nJSVQA0Zc0EeH6j/xGAiTm7URh/2/gANOL5G4Zxtd7YKW4AEw7iwRMz52+W1gCM3XUtxHphfNI4AUx2ZnzTMK6qimVjBTCZIF7vUo8b3YFndgwwGevm643C+ITxAhi72Ojx/NBhXG0AEcgADcyKN5oZb/gPATCy6IkXRw7j6kXeGeMHMBbrvrgbZmYcnjR+AGOxYZ5uGMZmxwBjcaJ6F7e5MDY7Bpj8rHioMDY7BthaEN9sVjzszNjsGGBzNlxBMXIYV7PjE8YVYORZ8VAnYc6P8IseSo7XBBjW+V4QLw77Nw8dxlW6qysAhp/ADm2UmXGqUv6MMQbY0GJV704mjCsHkroC4EaW0yZahJHDuFqioa4AWN/nhn1pt9WZ8Upd4XomgLVi9cT5zfyD81v4lx5IbgQBWHGmF8Rf2uw/vOkwrqbhnzP+AGnLebiVmXGqpuMH/ByAjgfxpzbTE48tjKtAPpGG3O4HMIMObbYnHmsYV4Eci5tP+JkAHfNkNSHdsvkxflERyOf9bICOOLGVF3aD5sb5lf30/Q/t6H16ufex288JmPEgHuv7srlxf4UCGRDELQhjgQwI4paEsUAGBPFo5if1C1dr7j6VnPIGCOJ8M+OBWfLx3qf9fp7AFDo0yiHxrZsZD8yS478oTnoDpkn87v5AE0Hc2My4b4a8r/cpZsk7/JyBFltO5VGYje2dmGv6O+wF8kLv07eSF3tAOz1fzYgbvURjLtd32wvlo71PB/3cgRY51FQt0ZowrgJ5bzVLVlsAOZ2vZsPZjnSYyz0C1XrkmCXv9zwAGTw5zjMmpjaMB2bJ8XJvwbMBNOBMNRtebsMXM9e20emFcvwX6vGkugAmI8I3uuFW3eM518aRqqqLLyYv+IDxidURT7ehkpiaMO4L5YUqlPd7joCthHDvY7Hp5WozE8YDofx4FcrqC2AYy72Pk20P4akK475Q3lEFcgTzgmcNWMeZCOFxXYckjG8ezHt7nx7pfewzWwaz4FTunHu6LasjOhPGA8EcgfxZwQydC+CYBX+7bSsjOhvG68yYI5jjs/MvYLZE+J6NWXDO3XLCePRg3tEXynuqz2bOMD0z3wjcH0UI98L3zCx/s3Nd++lWAR2hvFB9fCjVLwOFNTTnchW2qfr8f9Xny7MevOv5fwEGAMjmjanXdVzIAAAAAElFTkSuQmCC';
    
    if ($("#dm-progress-message").length > 0) {
        $("#dm-progress-message").remove();
    }

    if (fa_icon==1) {
        fa_icon = '<i class="fa fa-spinner fa-spin" style="font-size: 20px;position: relative;top: -20px;right: -10px;color: #df1657;"></i>';
    }else if (fa_icon==2){
        fa_icon = '<i class="fa fa-check" style="font-size: 12px;position: relative;top: -25px;right: -15px;color: rgba(223, 22, 87, 0.67);border: 2px solid;border-radius: 17px;padding: 4px 4px;"></i>';
    }else if (fa_icon==3){
        fa_icon = '<i class="fa fa-info" style="font-size: 12px;position: relative;top: -25px;right: -15px;color: rgba(223, 22, 87, 0.67);border: 2px solid;border-radius: 17px;padding: 4px 8px;"></i>';
    }
    
    var id = generateToken(10);

    var block = '';


    block += '<div id="dm-progress-message" class="'+id+'_message" style="cursor:pointer;background: white;position: fixed;right: 50px;top: 71px;z-index: 10000;width: 100%;max-width: 270px;padding: 30px 20px;border-left: 4px solid #df1657;box-shadow: 0 4px 2px rgba(176, 176, 181, 0.16);border-top: 1px solid #e6e1e1;border-right: 1px solid #e6e1e1;border-bottom: 1px solid #e6e1e1;">';
    block += '<div style="position: relative">';
    block += '<img style="width: 29px;position: absolute;top: 50%;left: -14px;transform: translateY(-50%);" src="'+icon+'"/>';

    block += '<div style="position: absolute;top:0;right:0">'+fa_icon+'</div>';
    block += '<div style="padding:0 0 0 22px">'+message+'</div>';
    block += '<div style="padding: 0 0 0 22px;font-size: 11px;color: #d8dae0;bottom: -27px;position: absolute;right: -15px;">Dropmarket Chrome Extension.</div>';
    // block += '<span style="font-size: 26px;position: absolute;top: 50%;right: -14px;transform: translateY(-50%) rotate(45deg);color: #575757;font-weight: 900;"><span>+</span></span>';
    block += '</div>';
    block += '</div>';
    
    $('body #dm-progress-message').remove();
    $('body').append( block );
    
    if (auto_remove > 0) {
        setTimeout(() => {
            $('.'+id+'_message').fadeOut(500, function() { $(this).remove(); });
        }, auto_remove * 1000);
        
    }
}