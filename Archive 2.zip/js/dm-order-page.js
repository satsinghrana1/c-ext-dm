window.addEventListener("load", pageFullyLoaded, false);
function pageFullyLoaded(){
    $(function() {
        console.log( "Ready! dm-order-page." );
        $('.order').click(function(p) {
            var dm_order_process = [
                'dm_order_btn_clk'  : 1,
                'dm_empty_cart'     : 0,
                'dm_add_to_cart'    : 0,
                'dm_empty_address'  : 0,
                'dm_create_address' : 0,
                'dm_fill_o_note'    : 0,
                'dm_process_done'   : 0,
            ];
            // initiate_process_state
            chrome.storage.sync.set({dm_order_process: dm_order_process});        
        })
    });
}